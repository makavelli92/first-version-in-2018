﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
using LevelStrategy.Model;
using System.Runtime.InteropServices;
using LevelStrategy.DAL;
using LevelStrategy.BL;
using Microsoft.VisualBasic;

namespace LevelStrategy
{
    public partial class MainForm : Form
    {
        string[] tempVol = { "SBER", "GAZP", "LKOH", "MOEX", "NVTK", "VTBR", "ROSN", "GMKN", "CHMF", "NLMK" };
        private static Mutex mtx;

        public DataReception data;

        public static DataGridView grid;
        public static DataGridView gridFakePos;
        public static DataGridView gridPos;
        public static TextBox log;

        private bool cycleRead = true;
        private bool cycleWrite = true;

        private Task first;
        private Task two;

        private static List<HexEditor.CompLevelsColl> collection;
        private static List<HexEditor.CompLevelsColl> collectionHeadLevel;

        public MainForm()
        {
            InitializeComponent();

            collection = HexEditor.HexReader.GetDataLevelFromHexFile("C:\\ForQuikSave\\Save.tab");
            collectionHeadLevel = HexEditor.HexReader.GetDataLevelFromHexFile("C:\\ForQuikSave\\HeadLevel.tab");

           // TelegramSender.SendToChannel("StartProgramm", -1001298919824);
            mtx = new Mutex(false, "Sys");
            
            grid = this.dataGridView1;
            gridFakePos = this.gridFakeLevel;
            gridPos = this.gridPosition;
            log = this.tbLog;

            AddItemToCb();

            data = new DataReception();
            first = Task.Run(() =>
            {
                data.Start(ref cycleRead);
            });
            two = Task.Run(() =>
            {
                data.CycleSetCommand(data.SW_Command, data.SR_FlagCommand, data.SW_FlagCommand, ref cycleWrite);
            });
        }


        private void AddItemToCb()
        {
            foreach (var item in Enum.GetValues(typeof(ClassCod)))
            {
                cbClass.Items.Add(item);
            }
            foreach (var item in Enum.GetValues(typeof(TimeFrame)))
            {
                cbTimeFrame.Items.Add(item);
            }
        }


        private void button1_Click(object sender, EventArgs e)
        {
            if (cbClass.Text != String.Empty && cbSecurity.Text != String.Empty && cbTimeFrame.Text != String.Empty && !this.data.listBars.Any(x => x.Name == cbSecurity.Text && x.TimeFrame == (int)Enum.GetValues(typeof(TimeFrame)).Cast<TimeFrame>().First(y => y.ToString() == cbTimeFrame.Text)))
            {
                TimeFrame frame = Enum.GetValues(typeof(TimeFrame)).Cast<TimeFrame>().First(x => x.ToString() == cbTimeFrame.Text);
                string classCod = cbClass.Text;
                string security = cbSecurity.Text;

                data.listBars.Add(new Bars(classCod, security, (int)frame));

                MainForm.grid.Invoke(new Action(() =>
                {
                    MainForm.grid.Rows.Add(data.listBars.Last().Name + " " + data.listBars.Last().TimeFrame);
                    MainForm.grid.Rows[MainForm.grid.Rows.Count - 2].Cells[0].ReadOnly = true;
                    MainForm.grid.Rows[MainForm.grid.Rows.Count - 2].MinimumHeight = 35;
                }));

                data.AddToTimer(data.listBars.OfType<Bars>().Last().timeToAction, data.timers);


                Task.Run(() =>
                {
                    data.SetQUIKCommandDataObject(data.SW_Command, data.SR_FlagCommand, data.SW_FlagCommand, DataReception.GetCommandStringCb(classCod, security, frame), "GetCandle");
                });

                listSecurity.Text += cbSecurity.Text + "\n";
                listSecurity.AppendText(Environment.NewLine);
                cbClass.Text = String.Empty;
                cbSecurity.Text = String.Empty;
                cbTimeFrame.Text = String.Empty;
            }
        }
        private void cbClass_Leave(object sender, EventArgs e)
        {
            if (cbClass.Text != String.Empty)
            {
                if (cbClass.Text == "SPBFUT")
                {
                    cbSecurity.Items.Clear();
                    foreach (var item in Enum.GetValues(typeof(Futures)))
                    {
                        cbSecurity.Items.Add(item);
                    }
                }
                if (cbClass.Text == "TQBR")
                {
                    cbSecurity.Items.Clear();
                    foreach (var item in Enum.GetValues(typeof(Security)))
                    {
                        cbSecurity.Items.Add(item);
                    }
                }
                //   cbSecurity.Enabled = true;
            }
            else
            {
                cbSecurity.Items.Clear();
            }
        }
        public enum ClassCod
        {
            SPBFUT = 1,
            TQBR = 2,
            INDX = 3
        }
        public enum Index
        {
            IMOEX
        }
        public enum Futures
        {
            GZZ7,
            SRZ7,
            EuZ7,
            GDZ7,
            RIZ7,
            SiZ7,
            BRF8
        }
        public enum Security
        {
            SBER,
            SBERP,
            GAZP,
            LKOH,
            MTSS,
            MGNT,
            MOEX,
            NVTK,
            NLMK,
            RASP,
            VTBR,
            RTKM,
            ROSN,
            AFLT,
            AKRN,
            AFKS,
            PHOR,
            GMKN,
            CHMF,
            SNGS,
            URKA,
            FEES,
            ALRS,
            APTK,
            YNDX,
            MTLRP,
            MAGN,
            BSPB,
            MTLR
        }
        private void dataGridView1_RowHeaderMouseDoubleClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            if (data.listBars.Count > 0)
            {
                Bars temp = this.data.listBars.OfType<Bars>().FirstOrDefault(x => (x.Name + " " + x.TimeFrame) == (string)dataGridView1.Rows[e.RowIndex].Cells[0].Value);
                if (temp != null)
                {
                    FormAllSignal form = new FormAllSignal(data);
                    form.Text = temp.Name;
                    form.Show();
                    foreach (SignalData i in temp.listSignal)
                    {
                        form.dataGridView1.Rows.Add(String.Format($"{temp.Name} {temp.TimeFrame}"), i.SignalType, String.Format($"{i.pointsBars[0]} - {i.DateBsy.Day}  {i.DateBsy.ToShortTimeString()}"), i.DateBpy1.ToShortTimeString(), i.DateBpy2.ToShortTimeString(), i.Level, i.Lyft, i.CancelSignal, i.TimeNow.ToShortTimeString());
                        form.dataGridView1.Rows[form.dataGridView1.RowCount - 2].MinimumHeight = 35;
                        form.dataGridView1.Rows[form.dataGridView1.RowCount - 2].DefaultCellStyle.BackColor = i.color;
                    }
                }
            }
        }
        private void dataGridView1_RowHeaderMouseClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            this.dataGridView1.Rows[e.RowIndex].DefaultCellStyle.BackColor = Color.Empty;
        }

        private void MainForm_FormClosing(object sender, FormClosingEventArgs e)
        {
            cycleRead = false;
            cycleWrite = false;
            while (!first.IsCompleted && !two.IsCompleted)
                Thread.Sleep(100);
        }

        private List<ApplicationItem> listItem;
        private List<ApplicationItem> listItemTicks;

        

        private void button2_Click(object sender, EventArgs e)
        {
            if (listItem == null)
            {
                listItem = new List<ApplicationItem>();
                //listItem.Add(new ApplicationItem(global::LevelStrategy.DAL.ClassCod.SPBFUT, global::LevelStrategy.DAL.Futures.BRG8, TimeFrame.INTERVAL_M5, 13, new double[2] { 63.8, 63.4 }, "short"));
                //listItem.Add(new ApplicationItem(global::LevelStrategy.DAL.ClassCod.SPBFUT, global::LevelStrategy.DAL.Futures.EuH8, TimeFrame.INTERVAL_M5, 13, new double[2] { 69532, 69500 }));
                //listItem.Add(new ApplicationItem(global::LevelStrategy.DAL.ClassCod.SPBFUT, global::LevelStrategy.DAL.Futures.GDH8, TimeFrame.INTERVAL_M5, 13, new double[2] { 1263, 1262 }));
                //listItem.Add(new ApplicationItem(global::LevelStrategy.DAL.ClassCod.SPBFUT, global::LevelStrategy.DAL.Futures.RIH8, TimeFrame.INTERVAL_M5, 13, new double[2] { 113000, 112800 }));
                //listItem.Add(new ApplicationItem(global::LevelStrategy.DAL.ClassCod.SPBFUT, global::LevelStrategy.DAL.Futures.SiH8, TimeFrame.INTERVAL_M5, 13, new double[2] { 58850, 58765 }));



                listItem.Add(new ApplicationItem(global::LevelStrategy.DAL.ClassCod.TQBR, global::LevelStrategy.DAL.Security.SBER, TimeFrame.INTERVAL_M5, 21));
                listItem.Add(new ApplicationItem(global::LevelStrategy.DAL.ClassCod.TQBR, global::LevelStrategy.DAL.Security.GAZP, TimeFrame.INTERVAL_M5, 21));
                listItem.Add(new ApplicationItem(global::LevelStrategy.DAL.ClassCod.TQBR, global::LevelStrategy.DAL.Security.LKOH, TimeFrame.INTERVAL_M5, 21));
                listItem.Add(new ApplicationItem(global::LevelStrategy.DAL.ClassCod.TQBR, global::LevelStrategy.DAL.Security.MOEX, TimeFrame.INTERVAL_M5, 21));
                listItem.Add(new ApplicationItem(global::LevelStrategy.DAL.ClassCod.TQBR, global::LevelStrategy.DAL.Security.ROSN, TimeFrame.INTERVAL_M5, 21));
                listItem.Add(new ApplicationItem(global::LevelStrategy.DAL.ClassCod.TQBR, global::LevelStrategy.DAL.Security.GMKN, TimeFrame.INTERVAL_M5, 21));

                listItem.Add(new ApplicationItem(global::LevelStrategy.DAL.ClassCod.INDX, global::LevelStrategy.DAL.Index.IMOEX, TimeFrame.INTERVAL_M5, 21));


                listItem.Add(new ApplicationItem(global::LevelStrategy.DAL.ClassCod.TQBR, global::LevelStrategy.DAL.Security.ALRS, TimeFrame.INTERVAL_M5, 21));
                listItem.Add(new ApplicationItem(global::LevelStrategy.DAL.ClassCod.TQBR, global::LevelStrategy.DAL.Security.MAGN, TimeFrame.INTERVAL_M5, 21));
                listItem.Add(new ApplicationItem(global::LevelStrategy.DAL.ClassCod.TQBR, global::LevelStrategy.DAL.Security.NLMK, TimeFrame.INTERVAL_M5, 21));
                listItem.Add(new ApplicationItem(global::LevelStrategy.DAL.ClassCod.TQBR, global::LevelStrategy.DAL.Security.SNGS, TimeFrame.INTERVAL_M5, 21));
                listItem.Add(new ApplicationItem(global::LevelStrategy.DAL.ClassCod.TQBR, global::LevelStrategy.DAL.Security.CHMF, TimeFrame.INTERVAL_M5, 21));
                listItem.Add(new ApplicationItem(global::LevelStrategy.DAL.ClassCod.TQBR, global::LevelStrategy.DAL.Security.NVTK, TimeFrame.INTERVAL_M5, 21));
                listItem.Add(new ApplicationItem(global::LevelStrategy.DAL.ClassCod.TQBR, global::LevelStrategy.DAL.Security.MGNT, TimeFrame.INTERVAL_M5, 21));
                listItem.Add(new ApplicationItem(global::LevelStrategy.DAL.ClassCod.TQBR, global::LevelStrategy.DAL.Security.RSTI, TimeFrame.INTERVAL_M5, 21));
                listItem.Add(new ApplicationItem(global::LevelStrategy.DAL.ClassCod.TQBR, global::LevelStrategy.DAL.Security.VTBR, TimeFrame.INTERVAL_M5, 21));

                listItem.Add(new ApplicationItem(global::LevelStrategy.DAL.ClassCod.TQBR, global::LevelStrategy.DAL.Security.YNDX, TimeFrame.INTERVAL_M5, 21));
                //  listItem.Add(new ApplicationItem(global::LevelStrategy.DAL.ClassCod.TQBR, global::LevelStrategy.DAL.Security.MTLR, TimeFrame.INTERVAL_M5, 21));
                //  listItem.Add(new ApplicationItem(global::LevelStrategy.DAL.ClassCod.TQBR, global::LevelStrategy.DAL.Security.BANEP, TimeFrame.INTERVAL_M5, 21));
                listItem.Add(new ApplicationItem(global::LevelStrategy.DAL.ClassCod.TQBR, global::LevelStrategy.DAL.Security.MTSS, TimeFrame.INTERVAL_M5, 21));
                //  listItem.Add(new ApplicationItem(global::LevelStrategy.DAL.ClassCod.TQBR, global::LevelStrategy.DAL.Security.AFKS, TimeFrame.INTERVAL_M5, 21));
                listItem.Add(new ApplicationItem(global::LevelStrategy.DAL.ClassCod.TQBR, global::LevelStrategy.DAL.Security.RASP, TimeFrame.INTERVAL_M5, 21));
                listItem.Add(new ApplicationItem(global::LevelStrategy.DAL.ClassCod.TQBR, global::LevelStrategy.DAL.Security.AFLT, TimeFrame.INTERVAL_M5, 21));

                // listItem.Add(new ApplicationItem(global::LevelStrategy.DAL.ClassCod.TQBR, global::LevelStrategy.DAL.Security.LSNGP, TimeFrame.INTERVAL_M5, 21));
                // listItem.Add(new ApplicationItem(global::LevelStrategy.DAL.ClassCod.TQBR, global::LevelStrategy.DAL.Security.DSKY, TimeFrame.INTERVAL_M5, 21));
                //listItem.Add(new ApplicationItem(global::LevelStrategy.DAL.ClassCod.TQBR, global::LevelStrategy.DAL.Security.AGRO, TimeFrame.INTERVAL_M5, 21));
                // listItem.Add(new ApplicationItem(global::LevelStrategy.DAL.ClassCod.TQBR, global::LevelStrategy.DAL.Security.LSRG, TimeFrame.INTERVAL_M5, 21));

                //   listItem.Add(new ApplicationItem(global::LevelStrategy.DAL.ClassCod.TQBR, global::LevelStrategy.DAL.Security.BSPB, TimeFrame.INTERVAL_M5, 21));
                listItem.Add(new ApplicationItem(global::LevelStrategy.DAL.ClassCod.TQBR, global::LevelStrategy.DAL.Security.SBERP, TimeFrame.INTERVAL_M5, 21));
                listItem.Add(new ApplicationItem(global::LevelStrategy.DAL.ClassCod.TQBR, global::LevelStrategy.DAL.Security.RTKM, TimeFrame.INTERVAL_M5, 21));
                //   listItem.Add(new ApplicationItem(global::LevelStrategy.DAL.ClassCod.TQBR, global::LevelStrategy.DAL.Security.PLZL, TimeFrame.INTERVAL_M5, 21));
                listItem.Add(new ApplicationItem(global::LevelStrategy.DAL.ClassCod.TQBR, global::LevelStrategy.DAL.Security.URKA, TimeFrame.INTERVAL_M5, 21));
                listItem.Add(new ApplicationItem(global::LevelStrategy.DAL.ClassCod.TQBR, global::LevelStrategy.DAL.Security.FEES, TimeFrame.INTERVAL_M5, 21));

                AddAllCb(listItem);
            }
        }

        private void SetAlias(Bars bars)
        {
            switch (bars.Name)
            {
                case "SBER": { bars.Alias = "Сбербанк"; break; }
                case "SBERP": { bars.Alias = "Сбербанк-п"; break; }
                case "GAZP": { bars.Alias = "ГАЗПРОМ ао"; break; }
                case "LKOH": { bars.Alias = "ЛУКОЙЛ"; break; }
                case "MTSS": { bars.Alias = "МТС-ао"; break; }
                case "MGNT": { bars.Alias = "Магнит ао"; break; }
                case "MOEX": { bars.Alias = "МосБиржа"; break; }
                case "NVTK": { bars.Alias = "Новатэк ао"; break; }
                case "NLMK": { bars.Alias = "НЛМК ао"; break; }
                case "RASP": { bars.Alias = "Распадская"; break; }
                case "VTBR": { bars.Alias = "ВТБ ао"; break; }
                case "RTKM": { bars.Alias = "Ростел -ао"; break; }
                case "ROSN": { bars.Alias = "Роснефть"; break; }
                case "AFLT": { bars.Alias = "Аэрофлот"; break; }
                case "AFKS": { bars.Alias = "Система ао"; break; }
                case "GMKN": { bars.Alias = "ГМКНорНик"; break; }
                case "CHMF": { bars.Alias = "СевСт-ао"; break; }
                case "SNGS": { bars.Alias = "Сургнфгз"; break; }
                case "URKA": { bars.Alias = "Уркалий-ао"; break; }
                case "FEES": { bars.Alias = "ФСК ЕЭС ао"; break; }
                case "ALRS": { bars.Alias = "АЛРОСА ао"; break; }
                case "YNDX": { bars.Alias = "Yandex clA"; break; }
                case "MTLRP": { bars.Alias = "Мечел ап"; break; }
                case "MAGN": { bars.Alias = "ММК"; break; }
                case "BSPB": { bars.Alias = "БСП ао"; break; }
                case "MTLR": { bars.Alias = "Мечел ао"; break; }
                case "RSTI": { bars.Alias = "Россети ао"; break; }
                case "BANE": { bars.Alias = "Башнефт ао"; break; }
                case "TATN": { bars.Alias = "Татнфт Зао"; break; }
                case "BANEP": { bars.Alias = "Башнефт ап"; break; }
                case "LSNGP": { bars.Alias = "Ленэнерг-п"; break; }
                case "LSRG": { bars.Alias = "ЛСР ао"; break; }
                case "PLZL": { bars.Alias = "Полюс"; break; }
                case "DSKY": { bars.Alias = "ДетскийМир"; break; }
                case "AGRO": { bars.Alias = "AGRO-гдр"; break; }
            }
        }
        
        private void SetLevelFromCollection(Bars bars, List<HexEditor.CompLevelsColl> coll)
        {
            HexEditor.CompLevelsColl temp = coll.FirstOrDefault(x => x.Name == bars.Alias);

            if (temp != null && temp.Levels.Count > 0)
                bars.keyLevel = temp.Levels.ToArray();
            else
            {
                Task.Run(() =>
                {
                    MessageBox.Show($"По инструменту {bars.Name} не добавлены уровни");
                });
            }

        }
        private void SetLevelFromCollection2(ref double[] array, HexEditor.CompLevelsColl comp)
        {
            if (comp != null && comp.Levels.Count > 0)
                array = comp.Levels.ToArray();
            else
            {
                Task.Run(() =>
                {
   //                 MessageBox.Show($"По инструменту {comp.Name} не добавлены уровни");
                });
            }

        }
        private void AddAllCb(List<ApplicationItem> listApp)
        {
            foreach (ApplicationItem i in listApp)
            {
                if (data.listBars.TrueForAll(x => x.Name != i.security || x.TimeFrame != (int)i.timeFrame))
                {
                    //cbClass.Text = i.classCod;
                    //cbSecurity.Text = i.security;
                    //cbTimeFrame.Text = i.timeFrame.ToString();

                    data.listBars.Add(new Bars(i.classCod, i.security, (int)i.timeFrame, i.fractalParam, i.level, i.longTrade, i.shortTrade));
                    
                        MainForm.grid.Rows.Add(data.listBars.Last().Name + " " + data.listBars.Last().TimeFrame);
                        MainForm.grid.Rows[MainForm.grid.Rows.Count - 2].Cells[0].ReadOnly = true;
                        MainForm.grid.Rows[MainForm.grid.Rows.Count - 2].MinimumHeight = 35;
                    

                    data.AddToTimer(data.listBars.OfType<Bars>().Last().timeToAction, data.timers);

                    Task.Run(() =>
                    {
                        data.SetQUIKCommandDataObject(data.SW_Command, data.SR_FlagCommand, data.SW_FlagCommand, DataReception.GetCommandStringCb(i.classCod, i.security, i.timeFrame), "GetCandle");
                    });

                    listSecurity.Text += cbSecurity.Text + "\n";
                    listSecurity.AppendText(Environment.NewLine);

                    SetAlias((Bars)data.listBars.Last());
                    Bars temp = data.listBars.Cast<Bars>().Last();
                    SetLevelFromCollection2( ref temp.keyLevel, collection.FirstOrDefault(x => x.Name == temp.Alias));
                    SetLevelFromCollection2(ref temp.headLevel, collectionHeadLevel.FirstOrDefault(x => x.Name == temp.Alias));
                }
            }
        }
        private void AddAllCbForTicks(List<ApplicationItem> listApp)
        {
            foreach (ApplicationItem i in listApp)
            {
                if (!data.listBars.Any(x => x.Name == i.security && x.TimeFrame == (int)i.timeFrame))
                {
                    //cbClass.Text = i.classCod;
                    //cbSecurity.Text = i.security;
                    //cbTimeFrame.Text = i.timeFrame.ToString();

                    data.listBars.Add(new Ticks(i.classCod, i.security, (int)i.timeFrame, i.findPattern));

                    data.AddToTimer(data.listBars.OfType<Ticks>().Last().timeToAction, data.timers);

                    Task.Run(() =>
                    {
                        data.SetQUIKCommandDataObject(data.SW_Command, data.SR_FlagCommand, data.SW_FlagCommand, DataReception.GetCommandStringCb(i.classCod, i.security, i.timeFrame), "GetCandle");
                    });

                    listSecurity.Text += cbSecurity.Text + "\n";
                    listSecurity.AppendText(Environment.NewLine);
                }
            }
        }
        [DllImport("user32.dll")]
        static extern bool SetWindowPos(IntPtr hWnd, IntPtr hWndInsertAfter, int X, int Y, int width, int height, uint flags);
        [DllImport("user32.dll")]
        public static extern IntPtr FindWindow(string lpClassName, string lpWindowName);

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            IntPtr calc = FindWindow(null, "FindLevel");
            if (calc != null)
            {
                if (checkBox1.Checked)
                    SetWindowPos(calc, (IntPtr)(-1), 0, 0, 0, 0, 0x0003);
                else
                    SetWindowPos(calc, (IntPtr)(-2), 0, 0, 0, 0, 0x0003);
            }
        }

        private SignalItem itemSign;

        private void dataGridView1_CellMouseDoubleClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            if (e.ColumnIndex == 0)
            {
                itemSign = new SignalItem();
                int temp = 0;
                foreach (DataGridViewCell cell in this.dataGridView1.Rows[e.RowIndex].Cells)
                {
                    itemSign.dataGridView1.Rows[0].Cells[temp++].Value = cell.Value;
                }
                itemSign.Show();
            }
            if (e.ColumnIndex == 1)
            {
                if (this.dataGridView1.Rows.Count > 1)
                {
                    string[] temp = this.dataGridView1.Rows[e.RowIndex].Cells[0].Value.ToString().Split();
                    Bars bars = (Bars)data.listBars.FirstOrDefault(x => x.Name == temp[0] && x.TimeFrame == Int32.Parse(temp[1]));
                    if (bars.listSignal != null && bars.listSignal.Count > 0)
                    {
                        SignalData signal = bars.listSignal.Last();
                        if (bars != null)
                        {
                            Chart window = new Chart(bars, signal, data);
                            window.Show();
                        }
                    }
                }
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (this.dataGridView1.SelectedRows.Count > 0 && this.dataGridView1.SelectedRows[0].Cells[0].Value != null)
            {
                MutexWorker.MutexOn(mtx, "Удаление эитента из листа обработки");
                //  mtx.WaitOne();

                string[] temp = this.dataGridView1.SelectedRows[0].Cells[0].Value.ToString().Split();
                Data tmp = this.data.listBars.FirstOrDefault(x => x.Name == temp[0] && x.TimeFrame.ToString() == temp[1]);
                data.listBars.Remove(tmp);
                this.dataGridView1.Rows.RemoveAt(dataGridView1.SelectedRows[0].Index);

                MutexWorker.MutexOff(mtx, "Удаление эитента из листа обработки");
                //mtx.ReleaseMutex();
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            MutexWorker.MutexOn(mtx, "Изменение периода фрактала");
            //  mtx.WaitOne();
            for (int i = 0; i < this.dataGridView1.SelectedRows.Count; i++)
            {
                string[] temp = this.dataGridView1.SelectedRows[i].Cells[0].Value.ToString().Split();

                Bars tmp = (Bars)this.data.listBars.FirstOrDefault(x => x.Name == temp[0] && x.TimeFrame.ToString() == temp[1]);

                tmp.fractalPeriod = Int32.Parse(textBox1.Text);
            }
            MutexWorker.MutexOff(mtx, "Изменение периода фрактала");
            //mtx.ReleaseMutex();
            textBox1.Text = String.Empty;
        }
        static void EventSignal(object e, string str)
        {
            Task.Run(() => { MessageBox.Show(String.Format("{0} - {1}", str, DateTime.Now)); });
        }

        private void button5_Click(object sender, EventArgs e)
        {
            if (listItemTicks == null)
            {
                listItemTicks = new List<ApplicationItem>();

                listItemTicks.Add(new ApplicationItem(global::LevelStrategy.DAL.ClassCod.SPBFUT, global::LevelStrategy.DAL.Futures.GZM8, TimeFrame.INTERVAL_TICK, 0, new FindPattern(EventSignal, 25000, 4000, 9200, 5000, 1900, "GOLD")));

                AddAllCbForTicks(listItemTicks);
            }
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            List<Data> temp = new List<Data>(data.listBars);
            if(temp.Any(x => x.LastGet > DateTime.Now.AddHours(-1) && x.LastGet < DateTime.Now.AddMinutes(-10)))
            {
                SmtpClientHelper.SendEmail(String.Format($"Для {temp.First(x => x.LastGet > DateTime.Now.AddHours(-1) && x.LastGet < DateTime.Now.AddMinutes(-10)).Name} давно не поступало данных"),"Нет данных");
                TelegramSender.SendToChannel(String.Format($"Для {temp.First(x => x.LastGet > DateTime.Now.AddHours(-1) && x.LastGet < DateTime.Now.AddMinutes(-10)).Name} давно не поступало данных"), 532280918);
            }
        }

        private void button6_Click(object sender, EventArgs e)
        {
            TopSignals(grid.Rows);
        }

        private static void TopSignals(DataGridViewRowCollection rowsCollection)
        {
            DataGridViewRow[] temp = new DataGridViewRow[rowsCollection.Count];
            rowsCollection.CopyTo(temp, 0);
            rowsCollection.Clear();
            temp.Where(y => y.Cells[0].Value != null && y.Cells[0].Value.ToString() == "IMOEX 5").ToList().ForEach(x => rowsCollection.Add(x));
            temp.ToList().Remove(temp.Where(y => y.Cells[0].Value != null && y.Cells[0].Value.ToString() == "IMOEX 5").First());
            temp.Where(y => y.DefaultCellStyle.BackColor == Color.Lime && y.Cells[0].Value.ToString() != "IMOEX 5").ToList().ForEach(x => rowsCollection.Add(x));
            temp.Where(y => y.DefaultCellStyle.BackColor == Color.Gold && y.Cells[0].Value.ToString() != "IMOEX 5").ToList().ForEach(x => rowsCollection.Add(x));
            temp.Where(y => y.DefaultCellStyle.BackColor == Color.Brown && y.Cells[0].Value.ToString() != "IMOEX 5").ToList().ForEach(x => rowsCollection.Add(x));
            temp.Where(y => y.DefaultCellStyle.BackColor == Color.Coral && y.Cells[0].Value.ToString() != "IMOEX 5").ToList().ForEach(x => rowsCollection.Add(x));
            temp.Where(y => y.DefaultCellStyle.BackColor == Color.Cyan && y.Cells[0].Value.ToString() != "IMOEX 5").ToList().ForEach(x => rowsCollection.Add(x));
            temp.Where(y => 
            y.DefaultCellStyle.BackColor != Color.Lime && 
            y.DefaultCellStyle.BackColor != Color.Gold && 
            y.DefaultCellStyle.BackColor != Color.Brown &&
            y.DefaultCellStyle.BackColor != Color.Coral && 
            y.DefaultCellStyle.BackColor != Color.Cyan && y.Cells[0].Value != null && y.Cells[0].Value.ToString() != "IMOEX 5").ToList().ForEach(x => rowsCollection.Add(x));
          //  temp.Where(y => y.DefaultCellStyle.BackColor == Color.Empty && y.Cells[0].Value != null).ToList().ForEach(x => rowsCollection.Add(x));
        }

        private void timer2_Tick(object sender, EventArgs e)
        {
            Task.Run(() =>
            {
                data.SetQUIKCommandDataObject(data.SW_Command, data.SR_FlagCommand, data.SW_FlagCommand, "", "GetPositions");
            });
        }

        private void button7_Click(object sender, EventArgs e)
        {
            collection = HexEditor.HexReader.GetDataLevelFromHexFile("C:\\ForQuikSave\\Save.tab");
            collectionHeadLevel = HexEditor.HexReader.GetDataLevelFromHexFile("C:\\ForQuikSave\\HeadLevel.tab");
            MutexWorker.MutexOn(mtx, "RefreshLevels");
            data.listBars.Cast<Bars>().ToList().ForEach(x => SetLevelFromCollection2(ref x.keyLevel, collection.FirstOrDefault(y => y.Name == x.Alias)));
            data.listBars.Cast<Bars>().ToList().ForEach(x => SetLevelFromCollection2(ref x.headLevel, collectionHeadLevel.FirstOrDefault(y => y.Name == x.Alias)));
            MutexWorker.MutexOff(mtx, "RefreshLevels");
        }

        private void timer3_Tick(object sender, EventArgs e)
        {
            Task.Run(() => {
                int temp = ((int)(DateTime.Now.TimeOfDay.TotalMinutes / 5 + 1) * 5) - (int)DateTime.Now.TimeOfDay.TotalMinutes;
                Thread.Sleep(temp * 60000);
                Task.Run(() =>
                {
                    data.SetQUIKCommandDataObject(data.SW_Command, data.SR_FlagCommand, data.SW_FlagCommand, GetStringVolumeRequest(tempVol), "GetVolumes");
                });
            });
            
        }

        private string GetStringVolumeRequest(string[] securityArray)
        {
            StringBuilder builder = new StringBuilder();
            securityArray.ToList().ForEach(x => builder.Append($"TQBR;{x};5;"));
            return builder.ToString().Remove(builder.ToString().Length - 1);
        }

        private void dataGridView1_CellContextMenuStripNeeded(object sender, DataGridViewCellContextMenuStripNeededEventArgs e)
        {
            if (e.ColumnIndex != -1 && e.RowIndex != -1)
            {
                contextMenuStrip1.Show(Cursor.Position);
            }
        }

        private void ДобавитьУровень_Click(object sender, EventArgs e)
        {
            var point = grid.PointToClient(contextMenuStrip1.Bounds.Location);
            var info = grid.HitTest(point.X, point.Y);

            // Работаем с ячейкой
            var value = grid[info.ColumnIndex, info.RowIndex].Value;
            if (value != null)
            {
                Task.Run(() => {
                    MutexWorker.MutexOn(mtx, "AddNewLine");
                    ///необходимо сделать, чтобы мог искать в списке фьючерсы... сейчас режет неправильно(только для акций)
                    Bars bars = (Bars)data.listBars.FirstOrDefault(x => x.Name == value.ToString().Remove(4, 2));
                    if (bars != null)
                    {
                        bool flag = false;
                        while (!flag)
                        {
                            string lev = Interaction.InputBox($"Введи новый уровень", "").Replace(".", ",");
                            double t;
                            flag = Double.TryParse(lev, out t);
                            if (t > 0)
                                bars.listLevelNew.Add(DateTime.Now, t);
                        }
                    }
                    MutexWorker.MutexOff(mtx, "AddNewLine");
                });
            }
        }

        private void dataGridView1_MouseClick(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Right)
            {
                contextMenuStrip1.Show(Cursor.Position);
            }
        }

        private void toolStripMenuItem1_Click(object sender, EventArgs e)
        {
            DataGridView tabGrid = null;

            if (tabControl1.SelectedTab == this.tabPage1)
                tabGrid = grid;
            else if (tabControl1.SelectedTab == this.tabPage4)
                tabGrid = gridPosition;
            else
                return;

            var point = tabGrid.PointToClient(contextMenuStrip1.Location);
            var info = tabGrid.HitTest(point.X, point.Y);

            // Работаем с ячейкой
            var value = tabGrid[info.ColumnIndex, info.RowIndex].Value;
            if (value != null)
            {
                MutexWorker.MutexOn(mtx, "GetBarObject");
                ///необходимо сделать, чтобы мог искать в списке фьючерсы... сейчас режет неправильно(только для акций)

                Bars bars = null;
                if (tabControl1.SelectedTab == this.tabPage1)
                    bars = (Bars)data.listBars.FirstOrDefault(x => x.Name == value.ToString().Remove(4, 2));
                else if (tabControl1.SelectedTab == this.tabPage4)
                    bars = (Bars)data.listBars.FirstOrDefault(x => x.Name == value.ToString());

                if (bars != null)
                {
                    bars.ProcessType = "Accept";
                    MutexWorker.MutexOff(mtx, "GetBarObject");
                    Task.Run(() =>
                    {
                        data.SetQUIKCommandDataObject(data.SW_Command, data.SR_FlagCommand, data.SW_FlagCommand, bars.ClassCod + ';' + bars.Name + ';' + bars.TimeFrame + ';' + bars.Count, "GetCandle");
                    });
                    DateTime now = DateTime.Now;

                    while (now > bars.LastGet)
                        Thread.Sleep(100);

                    FastOrder window = new FastOrder(data, bars, bars.Close.Last(), "WithOrder");
                    window.Show();
                }
                else
                    MutexWorker.MutexOff(mtx, "GetBarObject");
            }
        }

        private void gridPosition_MouseClick(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Right)
            {
                contextMenuStrip1.Show(Cursor.Position);
            }
        }

        private void toolStripMenuItem2_Click(object sender, EventArgs e)
        {
            DataGridView tabGrid = null;

            if (tabControl1.SelectedTab == this.tabPage1)
                tabGrid = grid;
            else if (tabControl1.SelectedTab == this.tabPage4)
                tabGrid = gridPosition;
            else
                return;
            

            var point = tabGrid.PointToClient(contextMenuStrip1.Location);

            var info = tabGrid.HitTest(point.X, point.Y);

            // Работаем с ячейкой
            var value = tabGrid[info.ColumnIndex, info.RowIndex].Value;
            if (value != null)
            {
                MutexWorker.MutexOn(mtx, "GetBarObject");
                ///необходимо сделать, чтобы мог искать в списке фьючерсы...
                Bars bars = null;
                if (tabControl1.SelectedTab == this.tabPage1)
                    bars = (Bars)data.listBars.FirstOrDefault(x => x.Name == value.ToString().Remove(4, 2));
                else if (tabControl1.SelectedTab == this.tabPage4)
                    bars = (Bars)data.listBars.FirstOrDefault(x => x.Name == value.ToString());

                if (bars != null)
                {
                    bars.ProcessType = "Accept";
                    MutexWorker.MutexOff(mtx, "GetBarObject");
                    Task.Run(() =>
                    {
                        data.SetQUIKCommandDataObject(data.SW_Command, data.SR_FlagCommand, data.SW_FlagCommand, bars.ClassCod + ';' + bars.Name + ';' + bars.TimeFrame + ';' + bars.Count, "GetCandle");
                    });
                    DateTime now = DateTime.Now;

                    while (now > bars.LastGet)
                        Thread.Sleep(100);
                    if (tabControl1.SelectedTab == this.tabPage1)
                    {
                        FastOrder window = new FastOrder(data, bars, bars.Close.Last(), "WithoutOrder");
                        window.Show();
                    }
                    else if (tabControl1.SelectedTab == this.tabPage4)
                    {
                        string type = Int32.Parse(gridPosition.Rows[info.RowIndex].Cells[1].Value.ToString()) > 0 ? "Long" : "Short";
                        double stop = type == "Long" ? bars.Close.Last() - bars.Close.Last() * 0.01 : bars.Close.Last() + bars.Close.Last() * 0.01;
                        data.SetQUIKCommandDataObject(data.SW_Command, data.SR_FlagCommand, data.SW_FlagCommand, FastOrder.CreateTakeProfitStopLossString(bars, bars.Close.Last(), stop, Math.Abs(Int32.Parse(gridPosition.Rows[info.RowIndex].Cells[1].Value.ToString())) / Common.GetCountLot(value.ToString()), type), "SetTP_SL");
                    }
                }
                else
                    MutexWorker.MutexOff(mtx, "GetBarObject");
            }
        }

        private void button8_Click(object sender, EventArgs e)
        {
            Bars bars = (Bars)data.listBars.FirstOrDefault(x => x.ClassCod == ClassCod.INDX.ToString() && x.Name == "IMOEX");
            
            if (bars != null)
            {
                Chart window = new Chart(bars, data);
                window.Show();
            }

        }
    }
}

