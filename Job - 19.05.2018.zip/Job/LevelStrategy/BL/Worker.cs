﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using LevelStrategy.Model;
using NLog;
using System.Windows.Forms;
using LevelStrategy.BL.Strategy;
using System.Threading;
using System.Globalization;
using System.Diagnostics;
using System.IO;

namespace LevelStrategy.BL
{
    public static class Worker
    {
        private static readonly ILogger Logger = LogManager.GetLogger("info");
        public static void StartStrategy(Bars bars, Mutex mtx)
        {
            MutexWorker.MutexOn(mtx, "CalculateIndicators");
            int lastIndex = 0;
            if (bars.MovingAverage != null)
                lastIndex = bars.MovingAverage.Count - 1;
            if (bars.StepPrice == 0)
            {
                CalculateStepPrice(bars);
                bars.CountSigns = Common.GetSignCount(bars.StepPrice.ToString());
            }

            if (bars.MovingAverage != null && bars.MovingAverage.Count > 0)
                DeleteLastData(bars);

            MovingAverageCalculate(bars);

            IndicatorCalculate.FractalCalculate(bars, lastIndex, ref bars.indexFractalHigh, ref bars.indexFractalsLow, bars.fractalPeriod, bars.sdvig);
            IndicatorCalculate.FractalCalculate(bars, lastIndex, ref bars.indexFractalHighSecond,ref bars.indexFractalsLowSecond, bars.fractalPeriodSecond, bars.sdvigSecond);
            bars.StartIndex = 0; // менять, если сутки вышли с момента последней сессии -- уже не надо

            if (bars.AvgVolume == 0)
                AddVolumeSearch(bars);

            Logger.Warn($"{Thread.CurrentThread.ManagedThreadId} -Посчитал все индикаторы, отправляю на поиск сигнала");
            MutexWorker.MutexOff(mtx, "CalculateIndicators");

            ///
            
            RepeatLevel.FindSignal(bars, mtx, EventSignal);

            ///

            MaxVolume.FindVolume(bars);

            ///
            ConfigureHeadBars(bars);

            DoublePeak.FindSignal(bars, mtx, EventSignal);
        }

        public static void ConfigureHeadBars(Bars bars)
        {
            bars.HeadBars = RecalculateBarsToHeadTf(bars, bars.HeadBars, 60);
            bars.HeadBars.StartIndex = 5;
            IndicatorCalculate.FractalCalculate(bars.HeadBars, bars.HeadBars.Count - 1, ref bars.HeadBars.indexFractalHigh, ref bars.HeadBars.indexFractalsLow, 3, 0);
            bars.HeadBars.indexFractalHighSecond = bars.HeadBars.indexFractalHigh;
            bars.HeadBars.indexFractalsLowSecond = bars.HeadBars.indexFractalsLow;
        }
        public static Bars RecalculateBarsToHeadTf(Bars source, Bars result, int headTf)
        {
            if (headTf < source.TimeFrame)
                return null;

            String t;
            Bars temp;

            List<TimeSpan> time = Common.GetListTimeInFrame(source.ClassCod, source.TimeFrame, headTf);
            
            int startIndex;

            if (result == null)
                startIndex = source.Time.FindIndex(x => time.Contains(x.TimeOfDay));
            else
                startIndex = source.Time.FindIndex(x => result.Time.Last() == x);

            if (result != null)
            {
                t = String.Format($"{result.Time[result.Count - 1].ToShortDateString()}_{result.Time[result.Count - 1].ToShortTimeString()}  C -{result.Close[result.Count - 1]} O -{result.Open[result.Count - 1]} H -{result.High[result.Count - 1]} L -{result.Low[result.Count - 1]} V -{result.Volume[result.Count - 1]}");

                result.Time.RemoveRange(result.Time.Count - 1, 1);
                result.Open.RemoveRange(result.Open.Count - 1, 1);
                result.Close.RemoveRange(result.Close.Count - 1, 1);
                result.High.RemoveRange(result.High.Count - 1, 1);
                result.Low.RemoveRange(result.Low.Count - 1, 1);
                result.Volume.RemoveRange(result.Volume.Count - 1, 1);
                temp = result;
            }
            else
                temp = new Bars(source.Name.Remove(source.Name.Length - 1) + headTf, headTf);

            double close = source.Close[startIndex];
            double high = source.High[startIndex];
            double low = source.Low[startIndex];
            double volume = source.Volume[startIndex];

            if (source.Time[startIndex].TimeOfDay == time[0])
                temp.Time.Add(source.Time[startIndex].Date.AddHours(10).AddMinutes(-headTf));
            else
                temp.Time.Add(source.Time[startIndex]);
            temp.Open.Add(source.Open[startIndex]);

            for (int i = startIndex + 1; i < source.Time.Count; i++)
            {
                if (time.Contains(source.Time[i].TimeOfDay))// || i == source.Time.Count - 1)
                {
                    if (source.Time[i].TimeOfDay == time[0])
                        temp.Time.Add(source.Time[i].Date.AddHours(10).AddMinutes(-headTf));
                    else
                        temp.Time.Add(source.Time[i]);
                    temp.Open.Add(source.Open[i]);
                    temp.Close.Add(close);
                    temp.High.Add(high);
                    temp.Low.Add(low);
                    temp.Volume.Add(volume);

                    close = source.Close[i];
                    high = source.High[i];
                    low = source.Low[i];
                    volume = source.Volume[i];
                }
                else
                {
                    close = source.Close[i];
                    volume += source.Volume[i];
                    if (source.High[i] > high)
                        high = source.High[i];
                    if (source.Low[i] < low)
                        low = source.Low[i];
                }
            }

            temp.Close.Add(close);
            temp.High.Add(high);
            temp.Low.Add(low);
            temp.Volume.Add(volume);


            for (int i = 0; i < temp.Count; i++)
                Console.WriteLine(String.Format($"{temp.Time[i].ToShortDateString()}_{temp.Time[i].ToShortTimeString()}  C -{temp.Close[i]} O -{temp.Open[i]} H -{temp.High[i]} L -{temp.Low[i]} V -{temp.Volume[i]}"));

            
            return temp;
        }
        public static void VolumeCheck(String[] substrings, List<Data> listBars, Mutex mtx)
        {
            MutexWorker.MutexOn(mtx, "VolCheck");
            for (int i = 1; i < substrings.Length; i += 3)
            {
                Bars temp = listBars.Cast<Bars>().FirstOrDefault(x => x.Name == substrings[i]);
                if (temp != null && temp.AvgVolume > 1)
                {
                    if (temp.AvgVolume < Int32.Parse(substrings[i + 1]) && !temp.VolumeList.Contains(DateTime.Parse(substrings[i + 2])))
                    {
                        temp.VolumeList.Add(DateTime.Parse(substrings[i + 2]));
                        string vol = substrings[i + 1];
                        string time = substrings[i + 2];

                        Task.Run(() => { WriteInTb(temp.Name, temp.AvgVolume.ToString(), vol, time); });

                      //  TelegramSender.SendToChannel(String.Format($@"{temp.Name} - {vol} > {temp.AvgVolume} for bar {substrings[i + 2]} "), 532280918);
                    }
                }
            }
            MutexWorker.MutexOff(mtx, "VolCheck");
        }
        public static void WriteInTb(string name, string avgVol, string vol, string time)
        {
          //  Task.Run(() => { MessageBox.Show(String.Format($@"{name} - {vol} > {avgVol} for bar {time}")); });
            MainForm.grid.Invoke(new Action(() =>
            {
                MainForm.log.AppendText(String.Format($"{DateTime.Now.ToShortTimeString()} - {name} - {vol} > {avgVol} for bar  {time}") + Environment.NewLine);
            }));
        }
        private static void AddVolumeSearch(Bars bars)
        {
            string[] temp = { "SBER", "GAZP", "LKOH", "MOEX", "NVTK", "VTBR", "ROSN", "GMKN", "CHMF", "NLMK" };
            if (temp.ToList().Contains(bars.Name))
            {
                if (bars.AvgVolume == 0)
                {
                    bars.AvgVolume = AverageVolume(bars);
                  //  Task.Run(() => { MessageBox.Show($"{bars.Name}  - AverageVolume = {bars.AvgVolume}"); });
                }
            }
            else
                bars.AvgVolume = -1;
        }
        private static double AverageVolume(Bars bars)
        {
            List<double> temp = new List<double>();

            for (int i = 0; i < bars.Volume.Count; i++)
            {
                if (bars.Time[i].TimeOfDay > new TimeSpan(10, 01, 00) && bars.Time[i].TimeOfDay < new TimeSpan(18, 44, 00))
                    temp.Add(bars.Volume[i]);
            }
            temp.Sort();

            return temp[temp.Count / 100 * 96];
        }
        public static void AddAndCheckRowPosition(String[] substrings, List<Data> listBars, Mutex mtx)
        {
            List<Position> listPos = new List<Position>();
            for (int i = 1; i < substrings.Length; i += 10)
            {
                listPos.Add(new Position(
                    substrings[i], 
                    Int32.Parse(substrings[i + 1]), 
                    Double.Parse(substrings[i + 2].Replace('.', ',')), Int32.Parse(substrings[i + 3]),
                    substrings[i + 4] != "-"?DateTime.ParseExact(substrings[i + 4], "HHmmss", CultureInfo.InvariantCulture):DateTime.Now, 
                    Double.Parse(substrings[i + 5].Replace('.',',')),
                    Double.Parse(substrings[i + 6].Replace('.', ',')), 
                    Int32.Parse(substrings[i + 7]),
                    Double.Parse(substrings[i + 8].Replace('.', ',')), 
                    Int32.Parse(substrings[i + 9])));
            }
            AddAndCheckRowPosition(listPos, listBars, MainForm.gridPos, mtx);
        }
        private static void AddAndCheckRowPosition(List<Position> listPos, List<Data> listBars, DataGridView gridPos, Mutex mtx)
        {
            MainForm.gridPos.Invoke(new Action(() =>
            {
                foreach (Position i in listPos)
                {
                    int temp = Worker.GetRowNumber(gridPos.Rows, i.Name);
                    if (temp == -1)
                    {
                        AddRowPos(gridPos, listBars, i, mtx);
                        if (i.StopPrice > 0)
                            AddRowToFakeGrid(i.Name, i.CurrnetBalance > 0?"Long":"Short", i.AwgPositionPrice, i.StopPrice, i.CountLotsStop);
                        if (Math.Abs(i.CurrnetBalance) != i.StopCount)
                        {
                            Task.Run(() => { MessageBox.Show(String.Format($@"По инструменту - {i.Name} не выставлен стоп! СРОЧНО ВЫСТАВИ СТОП!")); });
                            TelegramSender.SendToChannel(String.Format($@"По инструменту - {i.Name} не выставлен стоп! СРОЧНО ВЫСТАВИ СТОП!"), -1001298919824);
                        }
                    }
                    else
                    {
                        double resaultPosMoney = CalculateResaultPosMoney(i.AwgPositionPrice, i.LastPrice, i.CurrnetBalance, i.CurrnetBalance > 0);
                        double resaultPercent = CalculateResaultPercent(resaultPosMoney, i.AwgPositionPrice * i.CurrnetBalance);
                        DataGridViewRow row = MainForm.gridPos.Rows[temp];
                        row.Cells[1].Value = i.CurrnetBalance;
                        row.Cells[2].Value = Math.Abs(i.CurrnetBalance * i.AwgPositionPrice);
                        row.Cells[3].Value = i.StopCount;
                        if(Double.Parse(row.Cells[4].Value.ToString()) < 0.4 && resaultPercent > 0.4)
                        {
                            Task.Run(() => { MessageBox.Show(String.Format($@"Цена {i.Name} достигла уровня перевода в безубыток!")); });
                            TelegramSender.SendToChannel(String.Format($@"Цена {i.Name} достигла уровня перевода в безубыток!"), -1001298919824);
                        }
                        row.Cells[4].Value = Math.Round(resaultPercent, 2);
                        row.Cells[5].Value = (int)resaultPosMoney;
                        row.Cells[6].Value = i.OpenBalance > 0 ? i.PosChange : Math.Round(resaultPercent,2);
                        row.Cells[7].Value = i.OpenBalance > 0 ? (int)(i.PosChange * i.CurrnetBalance * i.AwgPositionPrice)/100 : (int)resaultPosMoney;
                        if (i.StopPrice.ToString() != row.Cells[8].Value.ToString() && 
                        (i.CurrnetBalance > 0 ? (i.AwgPositionPrice > i.StopPrice && (100 - (i.StopPrice * 100 / i.AwgPositionPrice) > 0.2)) :
                        (i.AwgPositionPrice < i.StopPrice && (100 - (i.AwgPositionPrice * 100 / i.StopPrice)) > 0.2)))
                        {
                            AddRowToFakeGrid(i.Name, i.CurrnetBalance > 0 ? "Long" : "Short", i.AwgPositionPrice, i.StopPrice, i.CountLotsStop);
                        }
                        if(Math.Abs(i.CurrnetBalance) != i.StopCount)
                        {
                            Task.Run(() => { MessageBox.Show(String.Format($@"По инструменту - {i.Name} не выставлен стоп! СРОЧНО ВЫСТАВИ СТОП!")); });
                            TelegramSender.SendToChannel(String.Format($@"По инструменту - {i.Name} не выставлен стоп! СРОЧНО ВЫСТАВИ СТОП!"), -1001298919824);
                        }
                        row.Cells[8].Value = i.StopPrice;
                        row.Cells[9].Value = DateTime.Now.ToShortTimeString();
                    }
                }
                ChangeColorForGridPos(gridPos.Rows);
                CheckGridFakeForDeleteRow(MainForm.gridFakePos.Rows, listPos.Select(x => x.Name).ToList(), listBars, mtx);
            }));
        }
        private static void CheckGridFakeForDeleteRow(DataGridViewRowCollection rows, List<string> listPosName, List<Data> listBars, Mutex mtx)
        {
            MutexWorker.MutexOn(mtx, "CheckGridFakeForDeleteRow");
            List<DataGridViewRow> list = new List<DataGridViewRow>();
            foreach (DataGridViewRow i in rows)
            {
                if (i.Cells[0].Value != null && !listPosName.Contains(i.Cells[0].Value.ToString()))
                {
                    Bars temp = listBars.Cast<Bars>().FirstOrDefault(x => x.Name == i.Cells[0].Value.ToString());
                    if(temp != null)
                    {
                        if (CheckTpOrSlResult(Double.Parse(i.Cells[3].Value.ToString().Replace(".", ",")), i.Cells[1].Value.ToString(), temp))
                        {
                            list.Add(i);
                        }
                    }
                    // i.DefaultCellStyle.BackColor = Color.Violet;
                    //  DataGridViewCheckBoxCell cell = (DataGridViewCheckBoxCell)i.Cells[4];
                    //  cell.EditingCellFormattedValue = false;
                }
            }
 //wefqwfqwfqwdfqwdfqwdf         //  list.ForEach(x => MainForm.gridFakePos.Rows.Remove(x));   erferfwefwefwqfewfqwef
            MutexWorker.MutexOff(mtx, "CheckGridFakeForDeleteRow");
        }
        private static bool CheckTpOrSlResult(double stop, string type, Bars bars)
        {
            if(type == "Long")
            {
                for (int i = bars.Time.OrderByDescending(k => k).ToList().FindIndex(d => d < bars.timeToFindFakeLevel) + 1; i < bars.Low.Count; i++)
                {
                    if (i == -1)
                        break;
                    if (bars.Low[i] < stop)
                        return true;
                }
            }
            else if(type == "Short")
            {
                for (int i = bars.Time.FindIndex(d => d > bars.timeToFindFakeLevel); i < bars.High.Count; i++)
                {
                    if (i == -1)
                        break;
                    if (bars.High[i] > stop)
                        return true;
                }
            }
            return false;
        }
        private static void ChangeColorForGridPos(DataGridViewRowCollection rows)
        {
            foreach (DataGridViewRow i in rows)
            {
                if(i.Cells[0].Value != null)
                {
                    if (Double.Parse(i.Cells[5].Value.ToString().Replace(",", ".")) > 0)
                        i.DefaultCellStyle.BackColor = Color.Lime;
                    else
                        i.DefaultCellStyle.BackColor = Color.Red;
                    if (Int32.Parse(i.Cells[7].Value.ToString().Replace(",", ".")) > 0)
                    {
                        i.Cells[7].Style.BackColor = Color.Lime;
                        i.Cells[6].Style.BackColor = Color.Lime;
                    }
                    else
                    {
                        i.Cells[7].Style.BackColor = Color.Red;
                        i.Cells[6].Style.BackColor = Color.Red;
                    }
                    if (Double.Parse(i.Cells[8].Value.ToString()) == 0)
                        i.Cells[8].Style.BackColor = Color.Purple;
                    else
                        i.Cells[8].Style.BackColor = i.DefaultCellStyle.BackColor;


                }
            }
        }
        private static void AddRowPos(DataGridView grid, List<Data> listBars, Position pos, Mutex mtx)
        {
            MutexWorker.MutexOn(mtx, "AddRowPosition");

            double resaultPosMoney = CalculateResaultPosMoney(pos.AwgPositionPrice, pos.LastPrice, pos.CurrnetBalance, pos.CurrnetBalance > 0);
            double resaultPercent = CalculateResaultPercent(resaultPosMoney, pos.AwgPositionPrice * pos.CurrnetBalance);
            grid.Rows.Add(
                pos.Name, 
                pos.CurrnetBalance, 
                Math.Abs(pos.CurrnetBalance * pos.AwgPositionPrice), 
                pos.StopCount,
                Math.Round(resaultPercent, 2),
                (int)resaultPosMoney,
                pos.OpenBalance > 0?pos.PosChange:Math.Round(resaultPercent,2),
                pos.OpenBalance > 0 ? (int)(pos.PosChange * pos.CurrnetBalance * pos.AwgPositionPrice) / 100 : (int)resaultPosMoney,
                pos.StopPrice,
                DateTime.Now.ToShortTimeString()
                );

            MutexWorker.MutexOff(mtx, "AddRowPosition");
        }
        private static double CalculateResaultPosMoney(double priceEnter, double curPrice, int balance, bool vector)
        {
            return vector ? (double)(balance * curPrice - balance * priceEnter) - (double)((balance * priceEnter * 0.0005) - (double)(balance * curPrice * 0.0005)) :
                ((balance * priceEnter - balance * curPrice) - ((balance * priceEnter * 0.0005) - (balance * curPrice * 0.0005))) > 0? ((balance * priceEnter - balance * curPrice) - ((balance * priceEnter * 0.0005) - (balance * curPrice * 0.0005))) * (-1): ((balance * priceEnter - balance * curPrice) - ((balance * priceEnter * 0.0005) - (balance * curPrice * 0.0005)));
        }
        private static double CalculateResaultPercent(double moneyRes, double moneyEnter)
        {
            return moneyRes * 100 / moneyEnter;
        }

        private static void AddRowToFakeGrid(string name, string typePos, double enter, double stop, int lots)
        {
            if (typePos == "Long" && stop > enter)
                stop = enter * 0.996;
            else if (typePos == "Short" && stop < enter)
                stop = enter * 1.004;


            int temp = Worker.GetRowNumber(MainForm.gridFakePos.Rows, name);
            if (temp == -1)
            {
                int rowNumb = GetFirstEmptyRow(MainForm.gridFakePos.Rows);
                if(rowNumb == -1)
                {
                    MainForm.gridFakePos.Rows.Add(name, typePos[0] == 'S' ? "Short" : "Long", enter, stop);
                    MainForm.gridFakePos.Rows[MainForm.gridFakePos.Rows.Count - 2].Cells[0].Tag = lots / 2;
                    DataGridViewCheckBoxCell cell = (DataGridViewCheckBoxCell)MainForm.gridFakePos.Rows[MainForm.gridFakePos.Rows.Count - 2].Cells[4];
                    cell.EditingCellFormattedValue = true;
                    cell.Value = 1;
                    MainForm.gridFakePos.Rows[MainForm.gridFakePos.Rows.Count - 2].Cells[0].ReadOnly = true;
                    MainForm.gridFakePos.Rows[MainForm.gridFakePos.Rows.Count - 2].MinimumHeight = 35;

                }
                else
                {
                    DataGridViewRow row = MainForm.gridFakePos.Rows[rowNumb];
                    row.Cells[0].Value = name;
                    row.Cells[1].Value = typePos[0] == 'S' ? "Short" : "Long";
                    row.Cells[2].Value = enter;
                    row.Cells[3].Value = stop;
                    row.Cells[0].Tag = lots / 2;
                    DataGridViewCheckBoxCell cell = (DataGridViewCheckBoxCell)row.Cells[4];
                    cell.EditingCellFormattedValue = true;
                    cell.Value = 1;
                }
            }
            else
            {
                DataGridViewRow row = MainForm.gridFakePos.Rows[temp];
                row.Cells[1].Value = typePos[0] == 'S' ? "Short" : "Long";
                row.Cells[2].Value = enter;
                row.Cells[3].Value = stop;
                row.Cells[0].Tag = lots / 2;
            }
        }
        private static int GetFirstEmptyRow(DataGridViewRowCollection rowsCollection)
        {
            for (int i = 0; i < rowsCollection.Count; i++)
            {
                if (rowsCollection[i].Cells[0].Value == null)
                    return i;
            }
            return -1;
        }
        private static void CalculateStepPrice(Bars bars)
        {
            decimal stepPrice = 0;
            List<decimal> temp = new List<decimal>()
            {
            (decimal)10, (decimal)1, (decimal)0.5, (decimal)0.1, (decimal)0.05, (decimal)0.01, (decimal)0.005, (decimal)0.00005, (decimal)0.00001
            };

            foreach (decimal i in temp)
            {

                for (int bar = 0; bar < bars.Count; bar++)
                {
                    if (((decimal)bars.High[bar] / i) - (int)((decimal)bars.High[bar] / i) != 0)
                        break;
                    if (bar == bars.Count - 1)
                        stepPrice = i;
                }
                if (stepPrice != 0)
                    break;
            }
            bars.StepPrice = Convert.ToDouble(stepPrice);
        }
        
        static int GetRowNumber(DataGridViewRowCollection rowsCollection, string key)
        {
            for (int i = 0; i < rowsCollection.Count - 1; i++)
            {
                if ((string)rowsCollection[i].Cells[0].Value == key)
                    return i;
            }
            return -1;
        }

        public static void EventSignal(object e, SignalData data)
        {
            //  Logger.Debug($@"Сигнал получен для {data.NameSecurity}, время - " + DateTime.Now);
            int temp;
            if (MainForm.grid.InvokeRequired)
            {// перезаходим в метод потоком формы, чтобы не было исключения
                MainForm.grid.Invoke(new Action(() =>
                {
                    //   Logger.Debug($@"Сигнал получен для {data.NameSecurity}, время - " + DateTime.Now);
                    if (data.color == Color.Lime)
                        MainForm.log.AppendText(String.Format($"{DateTime.Now.ToShortTimeString()} - {data.NameSecurity} = {data.SignalType}") + Environment.NewLine);
                    temp = GetRowNumber(MainForm.grid.Rows, data.NameSecurity);

                    MainForm.grid.Rows[temp].Cells[1].Value = data.SignalType;
                    MainForm.grid.Rows[temp].Cells[2].Value = String.Format($"{data.pointsBars[0]} - {data.DateBsy.Day} {data.DateBsy.ToShortTimeString()}");
                    MainForm.grid.Rows[temp].Cells[3].Value = String.Format($"{data.pointsBars[1]} - {data.DateBpy1.ToShortTimeString()}"); ;
                    MainForm.grid.Rows[temp].Cells[4].Value = String.Format($"{data.pointsBars[2]} - {data.DateBpy2.ToShortTimeString()}"); ;
                    MainForm.grid.Rows[temp].Cells[5].Value = data.Level;
                    MainForm.grid.Rows[temp].Cells[6].Value = data.Lyft;
                    MainForm.grid.Rows[temp].Cells[7].Value = data.CancelSignal;
                    MainForm.grid.Rows[temp].Cells[8].Value = data.TimeNow.ToShortTimeString();
                    MainForm.grid.Rows[temp].DefaultCellStyle.BackColor = data.color;

                    ChangeColorCells(MainForm.grid.Rows);

                   // TopSignals(MainForm.grid.Rows);
                }));
                return;
            }
            
            temp = GetRowNumber(MainForm.grid.Rows, data.NameSecurity);
            MainForm.log.AppendText(String.Format($"{DateTime.Now.ToShortTimeString()} - {data.NameSecurity} = {data.SignalType}") + Environment.NewLine);

            MainForm.grid.Rows[temp].Cells[1].Value = data.SignalType;
            MainForm.grid.Rows[temp].Cells[2].Value = String.Format($"{data.pointsBars[0]} - {data.DateBsy.Day} {data.DateBsy.ToShortTimeString()}");
            MainForm.grid.Rows[temp].Cells[3].Value = String.Format($"{data.pointsBars[1]} - {data.DateBpy1.ToShortTimeString()}"); ;
            MainForm.grid.Rows[temp].Cells[4].Value = String.Format($"{data.pointsBars[2]} - {data.DateBpy2.ToShortTimeString()}"); ;
            MainForm.grid.Rows[temp].Cells[5].Value = data.Level;
            MainForm.grid.Rows[temp].Cells[6].Value = data.Lyft;
            MainForm.grid.Rows[temp].Cells[7].Value = data.CancelSignal;
            MainForm.grid.Rows[temp].Cells[8].Value = data.TimeNow.ToShortTimeString();
            MainForm.grid.Rows[temp].DefaultCellStyle.BackColor = data.color;

            ChangeColorCells(MainForm.grid.Rows);
        }

        private static void TopSignals(DataGridViewRowCollection rowsCollection)
        {
            DataGridViewRow[] temp = new DataGridViewRow[rowsCollection.Count];
            rowsCollection.CopyTo(temp, 0);
            rowsCollection.Clear();
            temp.Where(y => y.DefaultCellStyle.BackColor == Color.Brown).ToList().ForEach(x => rowsCollection.Add(x));
            temp.Where(y => y.DefaultCellStyle.BackColor == Color.Coral).ToList().ForEach(x => rowsCollection.Add(x));
            temp.Where(y => y.DefaultCellStyle.BackColor == Color.Cyan).ToList().ForEach(x => rowsCollection.Add(x));
            temp.Where(y => y.DefaultCellStyle.BackColor == Color.Gold).ToList().ForEach(x => rowsCollection.Add(x));
            temp.Where(y => y.DefaultCellStyle.BackColor == Color.Empty).ToList().ForEach(x => rowsCollection.Add(x));
        }

        private static void ChangeColorCells(DataGridViewRowCollection rowsCollection)
        {
            foreach (DataGridViewRow i in rowsCollection)
            {
                if (i.Cells[8].Value != null && /*(i.DefaultCellStyle.BackColor == Color.Cyan || i.DefaultCellStyle.BackColor == Color.Brown || i.DefaultCellStyle.BackColor == Color.Lime) &&*/ (DateTime.Parse(DateTime.Now.ToShortTimeString()) - DateTime.Parse(i.Cells[8].Value.ToString())).TotalMinutes > 5)
                {
                    if (i.DefaultCellStyle.BackColor == Color.Lime)
                        i.DefaultCellStyle.BackColor = Color.Gold;
                    else if (i.DefaultCellStyle.BackColor == Color.Brown)
                        i.DefaultCellStyle.BackColor = Color.Coral;
                    else if (i.DefaultCellStyle.BackColor == Color.Cyan)
                        i.DefaultCellStyle.BackColor = Color.Empty;
                }
            }
        }

        public static void DeleteLastData(Bars bars)
        {
            if (bars.MovingAverage.Last() != 0)
                bars.MovingAverage.RemoveAt(bars.MovingAverage.Count - 1);
        }

        public static void FractalCalculate(Bars bars, int lastIndex)
        {
            if (bars.indexFractalHigh == null)
                bars.indexFractalHigh = new List<int>();
            if (bars.indexFractalsLow == null)
                bars.indexFractalsLow = new List<int>();

            if (bars.indexFractalHigh.Count > 0 || bars.indexFractalsLow.Count > 0)
            {
                for (int i = lastIndex; i > lastIndex - bars.sdvig; i--)
                {
                    bars.indexFractalHigh.RemoveAll(x => x == i);
                    bars.indexFractalsLow.RemoveAll(x => x == i);
                }
            }
            for (int i = (bars.indexFractalHigh.Count == 0 && bars.indexFractalsLow.Count == 0) ? bars.Count - 1 - bars.periodStrategy - (int)bars.fractalPeriod : lastIndex - bars.sdvig; i < bars.Count; i++)
            {
                int fractalUp = FindFractalHigh(i, bars.fractalPeriod, bars.High);
                int fractalDown = FindFractalLow(i, bars.fractalPeriod, bars.Low);

                if (fractalUp != -1)
                {
                    if (!bars.indexFractalHigh.Contains(fractalUp))
                        bars.indexFractalHigh.Add(fractalUp);

                    for (int j = fractalUp - bars.sdvig >= 0 ? fractalUp - bars.sdvig : 0; j < fractalUp; j++)
                    {
                        if (bars.High[j] > /*bars.MovingAverage[j + bars.sdvig]) ;*/(bars.MovingAverage.Count - 1 >= j + bars.sdvig? bars.MovingAverage[j + bars.sdvig]: bars.MovingAverage.Last()))
                        {
                            if (!bars.indexFractalHigh.Contains(j))
                                bars.indexFractalHigh.Add(j);
                        }

                    }
                    for (int j = fractalUp + bars.sdvig <= bars.Count - 1 ? fractalUp + bars.sdvig : bars.Count - 1; j > fractalUp; j--)
                    {
                        if (bars.High[j] > bars.MovingAverage[j - bars.sdvig])
                        {
                            if (!bars.indexFractalHigh.Contains(j))
                                bars.indexFractalHigh.Add(j);
                        }
                    }
                }
                if (fractalDown != -1)
                {
                    if (!bars.indexFractalsLow.Contains(fractalDown))
                        bars.indexFractalsLow.Add(fractalDown);

                    for (int j = fractalDown - bars.sdvig >= 0 ? fractalDown - bars.sdvig : 0; j < fractalDown; j++)
                    {
                        if (bars.Low[j] < /*bars.MovingAverage[j + bars.sdvig]*/ (bars.MovingAverage.Count - 1 >= j + bars.sdvig? bars.MovingAverage[j + bars.sdvig]:bars.MovingAverage.Last()))
                        {
                            if (!bars.indexFractalsLow.Contains(j))
                                bars.indexFractalsLow.Add(j);
                        }
                    }

                    for (int j = fractalDown + bars.sdvig <= bars.Count - 1 ? fractalDown + bars.sdvig : bars.Count - 1; j > fractalDown; j--)
                    {
                        if (bars.Low[j] < bars.MovingAverage[j - bars.sdvig])
                        {
                            if (!bars.indexFractalsLow.Contains(j))
                                bars.indexFractalsLow.Add(j);
                        }
                    }
                }
            }
            bars.indexFractalHigh.Sort();
            bars.indexFractalsLow.Sort();
        }

        public static void ShowData(Bars bars)
        {
            Console.WriteLine(bars.LastTime);

            // Console.WriteLine("Count " +  bars.indexFractalsLow.Count);
            // Console.WriteLine("Last " + bars.Time[bars.indexFractalsLow.Last()]);
        }

        public static int FindFractalHigh(int i, double period, List<double> high)
        {
            int P = (int)Math.Floor(period / 2) * 2 + 1;
            if (i >= P)
            {
                int s = (int)(i - P + 1 + (int)Math.Floor(period / 2));

                double val_h = 0;
                for (int j = i - P + 1; j <= i; j++)
                {
                    if (high[j] > val_h)
                        val_h = high[j];
                }
                double h = high[s];
                if (val_h == h)
                    return s;
            }
            return -1;
        }
        public static int FindFractalLow(int i, double period, List<double> low)
        {
            int P = (int)Math.Floor(period / 2) * 2 + 1;
            if (i >= P)
            {
                int s = (int)(i - P + 1 + (int)Math.Floor(period / 2));

                double val_l = low[i - P + 1];
                for (int j = i - P + 2; j <= i; j++)
                {
                    if (low[j] < val_l)
                        val_l = low[j];
                }
                double l = low[s];
                if (val_l == l)
                    return s;
            }
            return -1;
        }

        public static void MovingAverageCalculate(Bars bars)
        {
            if (bars.MovingAverage == null)
            {
                bars.MovingAverage = new List<double>();
                for (int i = 0; i < bars.Count - 1 - bars.periodStrategy - bars.periodMoving - 1; i++)
                    bars.MovingAverage.Add(0);
            }

            switch (bars.movingCalculateType)
            {
                case "EMA":
                    {
                        EmaCalculateMA(bars);
                        break;
                    }
                default:
                    EmaCalculateMA(bars);
                    break;
            }
        }

        public static void EmaCalculateMA(Bars bars)
        {
            if (bars.Count >= bars.periodMoving)
            {
                //if (bars.MovingAverage.Count == bars.Count - 1 - bars.periodStrategy - bars.periodMoving - 1 )
                if (bars.MovingAverage.All(x => x == 0))
                {
                    bars.MovingAverage.Add(GetBarsValue(bars, bars.Count - 1 - bars.periodStrategy - bars.periodMoving - 1, bars.movingType));
                }
                for (int i = bars.MovingAverage.Count; i < bars.Count; i++)
                {
                    bars.MovingAverage.Add((bars.MovingAverage[i - 1] * (bars.periodMoving - 1) + 2 * GetBarsValue(bars, i, bars.movingType)) / (bars.periodMoving + 1));
                }
            }
        }

        public static double GetBarsValue(Bars bars, int index, string type)
        {
            switch (type)
            {
                case "Close":
                    {
                        return bars.Close[index];
                    }
                case "High":
                    {
                        return bars.High[index];
                    }
                case "Low":
                    {
                        return bars.Low[index];
                    }
                case "Median":
                    {
                        return (GetBarsValue(bars, index, "High") + GetBarsValue(bars, index, "Low")) / 2;
                    }
                default:
                    return 0;
            }
        }
        public static void CheckOrders(Bars tmp, Mutex mtx)
        {
            MutexWorker.MutexOn(mtx, "CheckOrders");
            //%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%//
            if (tmp.Orders.Count > 0)// && tmp.Orders.Any(x => x.StopProfitId > 0 && x.transactionId > 0))
            {
                CheckForKillOrders(tmp);//, SW_Command, SR_FlagCommand, SW_FlagCommand);
            }
            //%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%//
            
            MutexWorker.MutexOff(mtx, "CheckOrders");
        }
        private static void CheckForKillOrders(Bars bars)//, StreamWriter SW_Command, StreamReader SR_FlagCommand, StreamWriter SW_FlagCommand)
        {
            // Order order = bars.Orders.FirstOrDefault(x => x.deleteLevel > 0);
            List<Order> temp = new List<Order>();
            foreach (Order order in bars.Orders)
            {
                if (order.operation == "B")
                {
                    if (bars.High.Last() > order.deleteLevel)
                    {
                        Task.Run(() =>
                        {
                            MessageBox.Show($"Цена перешла границу захода по инструменту {bars.Name}! {bars.High.Last()} > {order.deleteLevel}");
                        });
                        SmtpClientHelper.SendEmail($"Цена перешла границу захода по инструменту {bars.Name}! {bars.High.Last()} > {order.deleteLevel}");
                        TelegramSender.SendToChannel($"Цена перешла границу захода по инструменту {bars.Name}! {bars.High.Last()} > {order.deleteLevel}", 532280918);
                        temp.Add(order);
                        //  bars.Orders.Remove(order);
                    }
                }
                if (order.operation == "S")
                {
                    if (bars.Low.Last() < order.deleteLevel)
                    {
                        Task.Run(() =>
                        {
                            MessageBox.Show($"Цена перешла границу захода по инструменту {bars.Name}! {bars.Low.Last()} < {order.deleteLevel}");
                        });
                        SmtpClientHelper.SendEmail($"Цена перешла границу захода по инструменту {bars.Name}! {bars.High.Last()} > {order.deleteLevel}");
                        TelegramSender.SendToChannel($"Цена перешла границу захода по инструменту {bars.Name}! {bars.High.Last()} > {order.deleteLevel}", 532280918);
                        temp.Add(order);
                        //  bars.Orders.Remove(order);
                    }
                }
            }
            temp.ForEach(x => bars.Orders.Remove(x));


            //if (order != null)
            //{
            //    if (order.operation == "B")
            //    {
            //        if (bars.High.Last() > order.deleteLevel)
            //        {
            //            Task.Run(() => { MessageBox.Show($"Цена перешла границу захода по инструменту {bars.Name}! {bars.High.Last()} > {order.deleteLevel}"); });
            //            bars.Orders.Remove(order);
            //        }
            //    }
            //    if (order.operation == "S")
            //    {
            //        if (bars.Low.Last() < order.deleteLevel)
            //        {
            //            Task.Run(() => { MessageBox.Show($"Цена перешла границу захода по инструменту {bars.Name}! {bars.Low.Last()} < {order.deleteLevel}"); });
            //            bars.Orders.Remove(order);
            //        }
            //    }
            //%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%//
            //Order order = bars.Orders.FirstOrDefault(x => x.transactionId > 0 && x.StopProfitId > 0 && x.numberOrder > 0 && x.numberStopProfitOrder > 0);
            //bool tmp = false;
            //if (order != null)
            //{
            //    if (order.operation == "B")
            //    {
            //        if (bars.High.Last() > order.deleteLevel)
            //        {
            //            DataReception.SetQUIKCommandData(SW_Command, SR_FlagCommand, SW_FlagCommand, bars.ClassCod + ';' + bars.Name + ';' + order.numberOrder + ';' + bars.Account, "KillOrder");
            //            DataReception.SetQUIKCommandData(SW_Command, SR_FlagCommand, SW_FlagCommand, bars.ClassCod + ';' + bars.Name + ';' + order.numberStopProfitOrder + ';' + bars.Account, "KillStopOrder");
            //            mtx.WaitOne();
            //            tmp = true;
            //            bars.Orders.Remove(order);
            //        }
            //    }
            //    if (order.operation == "S")
            //    {
            //        if (bars.Low.Last() < order.deleteLevel)
            //        {
            //            DataReception.SetQUIKCommandData(SW_Command, SR_FlagCommand, SW_FlagCommand, bars.ClassCod + ';' + bars.Name + ';' + order.numberOrder, "KillOrder");
            //            DataReception.SetQUIKCommandData(SW_Command, SR_FlagCommand, SW_FlagCommand, bars.ClassCod + ';' + bars.Name + ';' + order.numberStopProfitOrder, "KillStopOrder");
            //            mtx.WaitOne();
            //            tmp = true;
            //            bars.Orders.RemoveAll(x => x.transactionId == order.transactionId && x.StopProfitId == order.StopProfitId);
            //        }
            //    }
            //}
            //if (tmp)
            //    mtx.ReleaseMutex();
            //%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%//
        }
    }
}