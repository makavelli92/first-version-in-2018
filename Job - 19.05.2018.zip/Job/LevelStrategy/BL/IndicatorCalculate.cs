﻿using LevelStrategy.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LevelStrategy.BL
{
    public static class IndicatorCalculate
    {
        public static void FractalCalculate(Bars bars, int lastIndex,ref List<int> indexFractalHigh,ref List<int> indexFractalsLow, double fractalPeriod, int sdvig)
        {
            if (indexFractalHigh == null)
                indexFractalHigh = new List<int>();
            if (indexFractalsLow == null)
                indexFractalsLow = new List<int>();

            if (indexFractalHigh.Count > 0 || indexFractalsLow.Count > 0)
            {
                for (int i = lastIndex; i > lastIndex - sdvig; i--)
                {
                    indexFractalHigh.RemoveAll(x => x == i);
                    indexFractalsLow.RemoveAll(x => x == i);
                }
            }
            for (int i = (indexFractalHigh.Count == 0 && indexFractalsLow.Count == 0) ? bars.Count - 1 - bars.periodStrategy - (int)fractalPeriod : lastIndex - sdvig; i < bars.Count; i++)
            {
                int fractalUp = FindFractalHigh(i, fractalPeriod, bars.High);
                int fractalDown = FindFractalLow(i, fractalPeriod, bars.Low);

                if (fractalUp != -1)
                {
                    if (!indexFractalHigh.Contains(fractalUp))
                        indexFractalHigh.Add(fractalUp);

                    for (int j = fractalUp - sdvig >= 0 ? fractalUp - sdvig : 0; j < fractalUp; j++)
                    {
                        if (bars.High[j] > /*bars.MovingAverage[j + bars.sdvig]) ;*/(bars.MovingAverage.Count - 1 >= j + sdvig ? bars.MovingAverage[j + sdvig] : bars.MovingAverage.Last()))
                        {
                            if (!indexFractalHigh.Contains(j))
                                indexFractalHigh.Add(j);
                        }

                    }
                    for (int j = fractalUp + sdvig <= bars.Count - 1 ? fractalUp + sdvig : bars.Count - 1; j > fractalUp; j--)
                    {
                        if (bars.High[j] > bars.MovingAverage[j - sdvig])
                        {
                            if (!indexFractalHigh.Contains(j))
                                indexFractalHigh.Add(j);
                        }
                    }
                }
                if (fractalDown != -1)
                {
                    if (!indexFractalsLow.Contains(fractalDown))
                        indexFractalsLow.Add(fractalDown);

                    for (int j = fractalDown - sdvig >= 0 ? fractalDown - sdvig : 0; j < fractalDown; j++)
                    {
                        if (bars.Low[j] < /*bars.MovingAverage[j + bars.sdvig]*/ (bars.MovingAverage.Count - 1 >= j + sdvig ? bars.MovingAverage[j + sdvig] : bars.MovingAverage.Last()))
                        {
                            if (!indexFractalsLow.Contains(j))
                                indexFractalsLow.Add(j);
                        }
                    }

                    for (int j = fractalDown + sdvig <= bars.Count - 1 ? fractalDown + sdvig : bars.Count - 1; j > fractalDown; j--)
                    {
                        if (bars.Low[j] < bars.MovingAverage[j - sdvig])
                        {
                            if (!indexFractalsLow.Contains(j))
                                indexFractalsLow.Add(j);
                        }
                    }
                }
            }
            indexFractalHigh.Sort();

            indexFractalsLow.Sort();
        }

        public static int FindFractalHigh(int i, double period, List<double> high)
        {
            int P = (int)Math.Floor(period / 2) * 2 + 1;
            if (i >= P)
            {
                int s = (int)(i - P + 1 + (int)Math.Floor(period / 2));

                double val_h = 0;
                for (int j = i - P + 1; j <= i; j++)
                {
                    if (high[j] > val_h)
                        val_h = high[j];
                }
                double h = high[s];
                if (val_h == h)
                    return s;
            }
            return -1;
        }
        public static int FindFractalLow(int i, double period, List<double> low)
        {
            int P = (int)Math.Floor(period / 2) * 2 + 1;
            if (i >= P)
            {
                int s = (int)(i - P + 1 + (int)Math.Floor(period / 2));

                double val_l = low[i - P + 1];
                for (int j = i - P + 2; j <= i; j++)
                {
                    if (low[j] < val_l)
                        val_l = low[j];
                }
                double l = low[s];
                if (val_l == l)
                    return s;
            }
            return -1;
        }

    }
}
