﻿using LevelStrategy.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LevelStrategy.BL
{
    public static class Common
    {
        public static int GetCountLot(string name)
        {
            switch (name)
            {
                case "SBER":
                    return 10;
                case "MOEX":
                    return 10;
                case "ROSN":
                    return 10;
                case "NLMK":
                    return 10;
                case "LKOH":
                    return 1;
                case "GAZP":
                    return 10;
                case "URKA":
                    return 10;
                case "CHMF":
                    return 10;
                case "VTBR":
                    return 10000;
                case "MAGN":
                    return 100;
                case "MGNT":
                    return 1;
                case "NVTK":
                    return 10;
                case "SBERP":
                    return 100;
                case "GMKN":
                    return 1;
                case "ALRS":
                    return 100;
                case "MTSS":
                    return 10;
                case "PHOR":
                    return 1;
                case "AFLT":
                    return 100;
                case "YNDX":
                    return 1;
                case "MTLRP":
                    return 10;
                case "SNGS":
                    return 100;
                case "FEES":
                    return 10000;
                case "RTKM":
                    return 10;
                case "RASP":
                    return 10;
                case "GZ":
                    return 100;
                case "SR":
                    return 100;
                case "Eu":
                    return 1000;
                case "GD":
                    return 1;
                case "RI":
                    return 1;
                case "Si":
                    return 1000;
                case "BR":
                    return 10;
                default:
                    return -1;
            }
        }

        public static int GetIndexFirstBarToday(List<DateTime> times)
        {
            for (int i = times.Count - 1; i >= 0; i--)
            {
                if (times[i] < DateTime.Now.Date)
                    return i;
            }
            return -1;
        }

        public static double PercentDiffAbs(double fromNumber, double toNumber)
        {
            return (Math.Abs(fromNumber - toNumber) / fromNumber) * 100;
        }

        public static int GetSignCount(string number)
        {
            if (number.Contains("E"))
                return Int32.Parse(number.Remove(0, number.IndexOf('-') + 1));
            if (!number.Contains(","))
                return 1;
            return number.Length - 1 - number.IndexOf(',');
        }
        public static List<DateTime> CalculateListMinuts(int timeFrame, string classCod, int secondCycle)
        {
            List<DateTime> actionTime = new List<DateTime>();
            if (classCod == "TQBR")
            {
                if (timeFrame < 60)
                {
                    DateTime time = DateTime.Now.Date.AddHours(10);
                    DateTime fine = DateTime.Now.Date.AddHours(18).AddMinutes(45);

                    while (time <= fine)
                    {
                        if (time > DateTime.Now.Date.AddHours(10))
                            actionTime.Add(time.AddSeconds(-secondCycle));

                        time = time.AddMinutes(timeFrame);

                        if (time > DateTime.Now.Date.AddHours(18).AddMinutes(45) && !actionTime.Contains(DateTime.Now.Date.AddHours(18).AddMinutes(45).AddSeconds(-secondCycle)))
                            actionTime.Add(DateTime.Now.Date.AddHours(18).AddMinutes(45).AddSeconds(-secondCycle));
                    }
                }
                else if (timeFrame <= 240)
                {
                    DateTime time = DateTime.Now.Date.AddHours(10);
                    DateTime fine = DateTime.Now.Date.AddHours(18).AddMinutes(45);

                    while (time <= fine)
                    {
                        time = time.AddMinutes(timeFrame);

                        if (time >= DateTime.Now.Date.AddHours(18).AddMinutes(45) && !actionTime.Contains(DateTime.Now.Date.AddHours(18).AddMinutes(45).AddSeconds(-secondCycle)))
                        {
                            actionTime.Add(DateTime.Now.Date.AddHours(18).AddMinutes(45).AddSeconds(-secondCycle));
                        }
                        else
                            actionTime.Add(time.AddSeconds(-secondCycle));
                    }
                }
            }
            else if (classCod == "SPBFUT")
            {
                if (timeFrame < 60)
                {
                    DateTime time = DateTime.Now.Date.AddHours(10);
                    DateTime fine = DateTime.Now.Date.AddHours(23).AddMinutes(50);

                    while (time <= fine)
                    {
                        time = time.AddMinutes(timeFrame);

                        if (time >= DateTime.Now.Date.AddHours(18).AddMinutes(45) && !actionTime.Contains(DateTime.Now.Date.AddHours(18).AddMinutes(45).AddSeconds(-secondCycle)))
                        {
                            actionTime.Add(DateTime.Now.Date.AddHours(18).AddMinutes(45).AddSeconds(-secondCycle));
                        }
                        else if (time < DateTime.Now.Date.AddHours(18).AddMinutes(45))
                            actionTime.Add(time.AddSeconds(-secondCycle));
                    }

                    time = DateTime.Now.Date.AddHours(19);
                    fine = DateTime.Now.Date.AddHours(23).AddMinutes(50);

                    while (time <= fine)
                    {
                        time = time.AddMinutes(timeFrame);

                        if (time >= DateTime.Now.Date.AddHours(23).AddMinutes(50) && !actionTime.Contains(DateTime.Now.Date.AddHours(23).AddMinutes(50).AddSeconds(-secondCycle)))
                            actionTime.Add(DateTime.Now.Date.AddHours(23).AddMinutes(50).AddSeconds(-secondCycle));
                        else if (time < DateTime.Now.Date.AddHours(23).AddMinutes(50))
                            actionTime.Add(time.AddSeconds(-secondCycle));
                    }
                }
                else if (timeFrame <= 240)
                {
                    DateTime time = DateTime.Now.Date.AddHours(10);
                    DateTime fine = DateTime.Now.Date.AddHours(23).AddMinutes(50);

                    while (time <= fine)
                    {
                        time = time.AddMinutes(timeFrame);

                        if (time >= DateTime.Now.Date.AddHours(18).AddMinutes(45) && time <= DateTime.Now.Date.AddHours(19))
                        {
                            actionTime.Add(DateTime.Now.Date.AddHours(18).AddMinutes(45).AddSeconds(-secondCycle));
                        }
                        else if (time >= DateTime.Now.Date.AddHours(23).AddMinutes(50) && !actionTime.Contains(DateTime.Now.Date.AddHours(23).AddMinutes(50).AddSeconds(-secondCycle)))
                            actionTime.Add(DateTime.Now.Date.AddHours(23).AddMinutes(50).AddSeconds(-secondCycle));
                        else
                            actionTime.Add(time.AddSeconds(-secondCycle));
                    }
                }
            }
            actionTime.RemoveAll(x => x < DateTime.Now);
            return actionTime;
        }
        public static List<TimeSpan> GetListTimeInFrame(string classCod, int fromTf, int toTf)
        {
            List<TimeSpan> time = new List<TimeSpan>();

            if (classCod == "TQBR" || classCod == "INDX")
            {
                if (toTf < 60)
                {
                    DateTime start = DateTime.Now.Date.AddHours(10);
                    DateTime fine = DateTime.Now.Date.AddHours(18).AddMinutes(45);

                    while (start <= fine)
                    {

                    }
                }
                else if (toTf <= 240)
                {
                    time.Add(new TimeSpan(10, 0, 0).Add(new TimeSpan(0, -fromTf, 0)));

                    TimeSpan start = new TimeSpan(10, 0, 0);
                    TimeSpan fine = new TimeSpan(18, 45, 0);
                    TimeSpan step = new TimeSpan(0, toTf, 0);

                    while (start <= fine)
                    {
                        time.Add(start);
                        start += step;
                    }
                }
            }
            return time;
        }

        public static double PercentDiff(double fromNumb, double toNumb)
        {
            return (Math.Abs(fromNumb - toNumb) / fromNumb) * 100;
        }
    }
}
