﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using LevelStrategy.DAL;
using LevelStrategy.Model;
using Microsoft.VisualBasic;

namespace LevelStrategy.BL
{
    public static class FakeLevelStrategy
    {
        public static bool CheckFakePosition(DataReception data, Bars bars, DataGridViewRow row)
        {
            double stop = Double.Parse(row.Cells[3].Value.ToString().Replace(".", ","));
            double level = Double.Parse(row.Cells[2].Value.ToString().Replace(".",","));
            int barStart = -1;
            for (int i = 0; i < bars.Time.Count; i++)
            {
                if (bars.timeToFindFakeLevel <= bars.Time[i])
                {
                    barStart = i;
                    break;
                }
            }

            if (row.Cells[1].Value.ToString() == "Long" && barStart != -1)
            {
                for (int i = barStart; i < bars.Low.Count; i++)
                {
                    if (bars.Low[i] < stop)
                    {
                        for (int j = i; j < bars.Low.Count; j++)
                        {
                            if (bars.High[j] > level)
                            {
                                string temp = String.Empty;
                                TelegramSender.SendToChannel(String.Format($@"^^^^^^^^ЛОЖНЫЙ ПРОБОЙ ПО ИНСТРУМЕНТУ {bars.Alias} - {bars.Name}"), -1001298919824);
                                Task.Run(() =>
                                {
                                    temp = Interaction.InputBox($"Размещяем заявку для {bars.Alias}", "ЛОЖНЫЙ ПРОБОЙ!!!", row.Cells[0].Tag.ToString());
                                    int t;
                                    if(Int32.TryParse(temp, out t))
                                    {
                                        data.SetQUIKCommandDataObject(data.SW_Command, data.SR_FlagCommand, data.SW_FlagCommand, CreateOrderString(bars, level, t, row.Cells[1].Value.ToString()), "SetOrder");
                                        data.SetQUIKCommandDataObject(data.SW_Command, data.SR_FlagCommand, data.SW_FlagCommand, CreateTakeProfitStopLossString(bars, level, stop, t, row.Cells[1].Value.ToString()), "SetTP_SL");
                                    }
                                    MessageBox.Show($@"^^^^^^^^ЛОЖНЫЙ ПРОБОЙ ПО ИНСТРУМЕНТУ {bars.Alias} - {bars.Name}");
                                });
                                return true;
                            }
                        }
                    }
                }
            }
            else if (row.Cells[1].Value.ToString() == "Short" && barStart != -1)
            {
                for (int i = barStart; i < bars.High.Count; i++)
                {
                    if (bars.High[i] > stop)
                    {
                        for (int j = i; j < bars.High.Count; j++)
                        {
                            if (bars.Low[j] < level)
                            {
                                string temp = String.Empty;
                                TelegramSender.SendToChannel(String.Format($@"^^^^^^^^ЛОЖНЫЙ ПРОБОЙ ПО ИНСТРУМЕНТУ {bars.Alias} - {bars.Name}"), -1001298919824);
                                Task.Run(() =>
                                {
                                    temp = Interaction.InputBox($"Размещяем заявку для {bars.Alias}", "ЛОЖНЫЙ ПРОБОЙ!!!", row.Cells[0].Tag.ToString());
                                    int t;
                                    if (Int32.TryParse(temp, out t))
                                    {
                                        data.SetQUIKCommandDataObject(data.SW_Command, data.SR_FlagCommand, data.SW_FlagCommand, CreateOrderString(bars, level, t, row.Cells[1].Value.ToString()), "SetOrder");
                                        data.SetQUIKCommandDataObject(data.SW_Command, data.SR_FlagCommand, data.SW_FlagCommand, CreateTakeProfitStopLossString(bars, level, stop, t, row.Cells[1].Value.ToString()), "SetTP_SL");
                                    }
                                    MessageBox.Show($@"^^^^^^^^ЛОЖНЫЙ ПРОБОЙ ПО ИНСТРУМЕНТУ {bars.Alias} - {bars.Name}");
                                });
                                return true;
                            }
                        }
                    }
                }
            }
            return false;
        }

        private static string CreateTakeProfitStopLossString(Bars bars, double level, double stopLevel, int count, string type)
        {
            int profit_size = (int)Math.Abs(((level - stopLevel) * 3) / bars.StepPrice);
            int stop_size = (int)(Math.Abs((level - stopLevel) / bars.StepPrice));
            StringBuilder builder = new StringBuilder();
            builder.Append(bars.Account).Append(';');
            builder.Append(bars.ClassCod).Append(';');
            builder.Append(bars.Name).Append(';');
            builder.Append(type[0] == 'S' ? "B" : "S").Append(';');
            builder.Append(level).Append(';');
            builder.Append(count).Append(';');
            builder.Append(profit_size).Append(';');
            builder.Append(stop_size);
            return builder.ToString();
        }

        private static string CreateOrderString(Bars bars, double level, int count, string type)
        {
            StringBuilder builder = new StringBuilder();
            builder.Append(bars.Account).Append(';');
            builder.Append(bars.ClassCod).Append(';');
            builder.Append(bars.Name).Append(';');
            builder.Append(level).Append(';');
            builder.Append(type[0] == 'S' ? "S" : "B").Append(';');
            builder.Append(count);
            return builder.ToString();
        }
    }
}
