﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using LevelStrategy.DAL;
using LevelStrategy.Model;
using NLog;
using System.Windows.Forms;

namespace LevelStrategy.BL.Repository
{
    public class Repository
    {
        private static readonly ILogger Logger = LogManager.GetLogger("info");

        private static readonly Mutex mtx = new Mutex(false, "Sys");

        public static void RemoveBarsIndex(Bars bars, int index)
        {
            bars.Open.RemoveAt(index);
            bars.Close.RemoveAt(index);
            bars.High.RemoveAt(index);
            bars.Low.RemoveAt(index);
            bars.Volume.RemoveAt(index);
            bars.Time.RemoveAt(index);
        }
        #region AddOrderAndProfitID
        private static void AddOrder(List<Data> listBars, String[] substrings)
        {
            MutexWorker.MutexOn(mtx, "Добавление ордера");
            //mtx.WaitOne();

            Bars temp = (Bars)listBars.FirstOrDefault(x => x.ClassCod == substrings[1] && x.Name == substrings[2] && x.Orders.Any(y => y.price == Double.Parse(substrings[3]) && y.operation == substrings[4]));

            Order order = temp.Orders.FirstOrDefault(y => y.price == Double.Parse(substrings[3]) && y.operation == substrings[4]);

            order.transactionId = Int64.Parse(substrings[6]);

            MutexWorker.MutexOff(mtx, "Добавление ордера");
            //mtx.ReleaseMutex();
        }

        private static void AddStopProfitId(List<Data> listBars, String[] substrings)
        {
            MutexWorker.MutexOn(mtx, "Добавление тэйк и стоп профит айди");
            //mtx.WaitOne();

            Bars temp = (Bars)listBars.FirstOrDefault(x => x.ClassCod == substrings[1] && x.Name == substrings[2] && x.Orders.Any(y => y.OnlyOrder));

            Order order = temp.Orders.FirstOrDefault(y => y.OnlyOrder);

            order.StopProfitId = Int64.Parse(substrings[6]);

            MutexWorker.MutexOff(mtx, "Добавление тэйк и стоп профит айди");
            //mtx.ReleaseMutex();
        }
        #endregion
        
        #region CheckOreder
        public static void CheckOrders(List<Data> listBars, String[] substrings, StreamWriter SW_Command, StreamReader SR_FlagCommand, StreamWriter SW_FlagCommand)
        {
            Bars bars = (Bars)listBars.FirstOrDefault(x => x.Name == substrings[1] && x.TimeFrame == Int32.Parse(substrings[2]) && x.Orders.Count > 0 && x.Orders.Any(y => y.StopProfitId > 0 && y.transactionId > 0));
            if (bars != null)
            {
                Order order = bars.Orders.FirstOrDefault(y => y.StopProfitId > 0 && y.transactionId > 0);
                bool tmp = false;
                if (substrings[3] == "DeleteAllOrders" || substrings[4] == "DeleteAllStopProfitOrders")
                {
                    if (substrings[3] == "DeleteAllOrders" && substrings[4] != "DeleteAllStopProfitOrders")
                    {
                        DataReception.SetQUIKCommandData(SW_Command, SR_FlagCommand, SW_FlagCommand, bars.ClassCod + ';' + bars.Name + ';' + order.numberStopProfitOrder + ';' + bars.Account, "KillStopOrder");
                        MutexWorker.MutexOn(mtx, "чекордер - первый иф");
                        //mtx.WaitOne();
                        tmp = true;
                        bars.Orders.RemoveAll(x => x.transactionId == order.transactionId && x.StopProfitId == order.StopProfitId);
                    }
                    if (substrings[3] != "DeleteAllOrders" && substrings[4] == "DeleteAllStopProfitOrders")
                    {
                        DataReception.SetQUIKCommandData(SW_Command, SR_FlagCommand, SW_FlagCommand, bars.ClassCod + ';' + bars.Name + ';' + order.numberOrder + ';' + bars.Account, "KillOrder");
                        MutexWorker.MutexOn(mtx, "чекордер - второй иф");
                        //mtx.WaitOne();
                        tmp = true;
                        bars.Orders.RemoveAll(x => x.transactionId == order.transactionId && x.StopProfitId == order.StopProfitId);
                    }
                    if (substrings[3] == "DeleteAllOrders" && substrings[4] == "DeleteAllStopProfitOrders" && !tmp)
                    {
                        MutexWorker.MutexOn(mtx, "чекордер - третий иф");
                        //mtx.WaitOne();
                        tmp = true;
                        bars.Orders.RemoveAll(x => x.transactionId == order.transactionId && x.StopProfitId == order.StopProfitId);
                    }

                }
                else
                {
                    MutexWorker.MutexOn(mtx, "чекордер - элсе");
                    //mtx.WaitOne();
                    tmp = true;
                    if (Int64.Parse(substrings[3]) != order.numberOrder)
                        order.numberOrder = Int64.Parse(substrings[3]);

                    if (Int64.Parse(substrings[4]) != order.numberStopProfitOrder)
                        order.numberStopProfitOrder = Int64.Parse(substrings[4]);
                }
                if (!tmp)
                {
                    MutexWorker.MutexOn(mtx, "чекордер - last if");
                    //mtx.WaitOne();
                }

                bars.LastCheckTable = DateTime.Now;
                bars.SendCheckTable = true;
                MutexWorker.MutexOff(mtx, "CheckOrders - one of them");
                //mtx.ReleaseMutex();
            }
        }
        #endregion
        public static Bars AddData(List<Data> listBars, String[] substrings, StreamWriter SW_Command, StreamReader SR_FlagCommand, StreamWriter SW_FlagCommand)
        {
            #region Логика для снятие заявок 
            //%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%//
            //if (substrings[0] == "orders")
            //{
            //    CheckOrders(listBars, substrings,  SW_Command,  SR_FlagCommand,  SW_FlagCommand);
            //    return;
            //}
            //if (substrings[0] == "Order")
            //{
            //    AddOrder(listBars, substrings);
            //    return;
            //}
            //else if (substrings[0] == "StopProfitOrder")
            //{
            //    AddStopProfitId(listBars, substrings);
            //    return;
            //}
            //%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%//
            #endregion
            MutexWorker.MutexOn(mtx, "AddData");
            Bars temp = listBars.Cast<Bars>().FirstOrDefault(x => x.Name == substrings[0] && x.TimeFrame == Int32.Parse(substrings[1]));
            if (temp != null || substrings[1] == "0")
            {
                if (substrings[1] != "0")
                {
                    Bars tmp = temp as Bars;

                    if (tmp.Count > 0 && !tmp.Time.Contains(DateTime.Parse(substrings[2])))
                    {
                        Task.Run(() =>
                        {
                            Logger.Warn($@"Не обнаружено прежних данных, формирую еще запрос на данные, теперь увеличу глубину запроса для - " + temp.ClassCod + ';' + temp.Name + ';' + temp.TimeFrame + ';');
                            MessageBox.Show("Не обнаружено прежних данных");
                            int tempCount = (DateTime.Parse(substrings[2]) - tmp.LastTime).Minutes / tmp.TimeFrame;
                            DataReception.SetQUIKCommandData(SW_Command, SR_FlagCommand, SW_FlagCommand, temp.ClassCod + ';' + temp.Name + ';' + temp.TimeFrame + ';' + (temp.Count - tempCount - 1), "GetCandle");
                        });
                        tmp.ProcessType = "SendCommand";
                        MutexWorker.MutexOff(mtx, "AddData");
                        return null;
                    }
                    if (tmp.Count == 0 && tmp.history)
                    {
                        DateTime time = tmp.From;
                        for (int i = 2; i < substrings.Length - 1; i += 6)
                        {
                            if (DateTime.Parse(substrings[i]) >= time)
                            {
                                tmp.temp = substrings.Length / 6 - (substrings.Length - i) / 6;
                                break;
                            }
                        }

                        for (int i = 2; i <= substrings.Length + -1; i += 6)
                        {
                            if (substrings[i] == String.Empty)
                                break;
                            if (tmp.Time.Contains(DateTime.Parse(substrings[i])))
                                RemoveBarsIndex(tmp, tmp.Time.IndexOf(DateTime.Parse(substrings[i])));
                            tmp.Time.Add(DateTime.Parse(substrings[i]));

                            tmp.Open.Add(Double.Parse(substrings[i + 1], CultureInfo.InvariantCulture));

                            tmp.High.Add(Double.Parse(substrings[i + 2], CultureInfo.InvariantCulture));

                            tmp.Low.Add(Double.Parse(substrings[i + 3], CultureInfo.InvariantCulture));

                            tmp.Close.Add(Double.Parse(substrings[i + 4], CultureInfo.InvariantCulture));

                            tmp.Volume.Add(Double.Parse(substrings[i + 5], CultureInfo.InvariantCulture));
                            if (tmp.Count > tmp.temp && tmp.first == "first" && tmp.history)
                            {
                                MutexWorker.MutexOff(mtx, "AddData"); //--
                                Worker.StartStrategy(tmp, mtx);
                                MutexWorker.MutexOn(mtx, "history");
                            }
                        }

                        Logger.Warn($"{Thread.CurrentThread.ManagedThreadId} {tmp.Name} - Поиск сигнала окончен возвращаю объект");
                        tmp.LastGet = DateTime.Now;

                        if (listBars.Cast<Bars>().All(x => x.LastGet > DateTime.Now.Date))
                            MessageBox.Show("По всем эмиетнтам история загружена!");
                    }
                    else // основной рабочий блок
                    {
                        for (int i = 2; i <= substrings.Length + -1; i += 6)
                        {
                            if (substrings[i] == String.Empty)
                                break;
                            if (tmp.Time.Contains(DateTime.Parse(substrings[i])))
                                RemoveBarsIndex(tmp, tmp.Time.IndexOf(DateTime.Parse(substrings[i])));
                            tmp.Time.Add(DateTime.Parse(substrings[i]));

                            tmp.Open.Add(Double.Parse(substrings[i + 1], CultureInfo.InvariantCulture));

                            tmp.High.Add(Double.Parse(substrings[i + 2], CultureInfo.InvariantCulture));

                            tmp.Low.Add(Double.Parse(substrings[i + 3], CultureInfo.InvariantCulture));

                            tmp.Close.Add(Double.Parse(substrings[i + 4], CultureInfo.InvariantCulture));

                            tmp.Volume.Add(Double.Parse(substrings[i + 5], CultureInfo.InvariantCulture));
                        }
                        
                        tmp.LastGet = DateTime.Now;
                        
                        Logger.Warn($"{Thread.CurrentThread.ManagedThreadId} {tmp.Name} -Данные принял и добавил успешно, отправляю на высчитыванеи индикаторов");
                    }
                }
                else
                {
                    FindPattern conf = listPattern.FirstOrDefault(x => x.name == substrings[0]);
                    if(conf != null)
                    {
                        Ticks ticks = new Ticks("secur", substrings[0], Int32.Parse(substrings[1]), conf);
                        if (substrings.Length <= 2)//if (substrings[2] == "0")
                        {
                            ticks.CountTicks = Int32.Parse(substrings[3]);
                            
                            Task.Run(() =>
                            {
                                int tempCount = ticks.CountTicks - 1 > -1 ? ticks.CountTicks - 1 : 0;
                                DataReception.SetQUIKCommandData(SW_Command, SR_FlagCommand, SW_FlagCommand, temp.ClassCod + ';' + temp.Name + ';' + temp.TimeFrame + ';' + (tempCount), "GetCandle");
                            });
                        }
                        else
                        {
                            for (int i = 2; i < substrings.Length - 1; i = i + 3)
                            {
                                ticks.Time.Add(DateTime.Parse(substrings[i]));

                                ticks.Close.Add(Double.Parse(substrings[i + 1], CultureInfo.InvariantCulture));

                                ticks.Volume.Add(Double.Parse(substrings[i + 2], CultureInfo.InvariantCulture));
                            }
                            ticks.Volume.Reverse();
                            ticks.Time.Reverse();


                            //  ticks = temp as Ticks;
                            //Task.Run(() =>
                            //{
                            //    MessageBox.Show($"ТИКИ пришли по {ticks.Name}. Первый - {ticks.Time.First()}. Последний - {ticks.Time.Last()}");
                            //});
                              ticks.worker.StartFind(ticks);
                        }
                    }
                    //else
                    //    Task.Run(() => { MessageBox.Show($"Нет настроек для {substrings[0]}");});


                    MutexWorker.MutexOff(mtx, "AddData");
                    return null;
                }
                //if (temp.ProcessType == "Accept")
                //{
                //    MutexWorker.MutexOn(mtx, "Change ProcessType");
                //    temp.ProcessType = "SendCommand";
                //    MutexWorker.MutexOff(mtx, "Change ProcessType");
                //}
            }
            MutexWorker.MutexOff(mtx, "AddData");
            
            return temp;
        }
        static Repository()
        {
            listPattern = new List<FindPattern>();

            listPattern.Add(new FindPattern(EventSignal, 250000, 40000, 70000, 60000, 8000, "SBER"));
            //listPattern.Add(new FindPattern(EventSignal, 250000, 4000, 9200, 5000, 1900, "GAZP"));
            //listPattern.Add(new FindPattern(EventSignal, 250000, 4000, 9200, 5000, 1900, "LKOH"));
            //listPattern.Add(new FindPattern(EventSignal, 250000, 4000, 9200, 5000, 1900, "MOEX"));
            //listPattern.Add(new FindPattern(EventSignal, 250000, 4000, 9200, 5000, 1900, "NVTK"));
            //listPattern.Add(new FindPattern(EventSignal, 250000, 4000, 9200, 5000, 1900, "VTBR"));
            //listPattern.Add(new FindPattern(EventSignal, 250000, 4000, 9200, 5000, 1900, "ROSN"));
            //listPattern.Add(new FindPattern(EventSignal, 250000, 4000, 9200, 5000, 1900, "GMKN"));
            //listPattern.Add(new FindPattern(EventSignal, 250000, 4000, 9200, 5000, 1900, "CHMF"));
            //listPattern.Add(new FindPattern(EventSignal, 250000, 4000, 9200, 5000, 1900, "NLMK"));
    }
        private static List<FindPattern> listPattern;
        static void EventSignal(object e, string str)
        {
          //  Task.Run(() => { MessageBox.Show(String.Format("{0} - {1}", str, DateTime.Now)); });
            Task.Run(() => {


                MainForm.grid.Invoke(new Action(() =>
                {
                    MainForm.log.AppendText(String.Format($"{DateTime.Now.ToShortTimeString()} - {str} - {DateTime.Now}") + Environment.NewLine);
                }));


            });
        }
    }
}
