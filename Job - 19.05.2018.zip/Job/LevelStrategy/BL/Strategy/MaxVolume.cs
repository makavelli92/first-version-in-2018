﻿using LevelStrategy.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LevelStrategy.BL.Strategy
{
    public static class MaxVolume
    {
        public static void FindVolume(Bars bars)
        {
            if (bars.AvgVolume != -1 && ((bars.Volume.Last() > bars.AvgVolume && !bars.VolumeList.Contains(bars.Time.Last())) ||
                bars.Volume[bars.Volume.Count - 2] > bars.AvgVolume && !bars.VolumeList.Contains(bars.Time[bars.Time.Count - 2])))
            {
                if (bars.Volume.Last() > bars.AvgVolume)
                {
                    bars.VolumeList.Add(bars.Time.Last());
                    //  Task.Run(() => { MessageBox.Show(String.Format($@"{bars.Name} - {bars.Volume.Last()} > {bars.AvgVolume} for bar {bars.Time.Last()} ")); });
                    MainForm.grid.Invoke(new Action(() =>
                    {
                        MainForm.log.AppendText(String.Format($"{DateTime.Now.ToShortTimeString()} - {bars.Name} - {bars.Volume.Last()} > {bars.AvgVolume} for bar {bars.Time.Last()} ") + Environment.NewLine);
                    }));
                    TelegramSender.SendToChannel(String.Format($@"{bars.Name} - {bars.Volume.Last()} > {bars.AvgVolume} for bar {bars.Time.Last()}"), 532280918);
                }

                else if (bars.Volume[bars.Volume.Count - 2] > bars.AvgVolume)
                {
                    bars.VolumeList.Add(bars.Time[bars.Time.Count - 2]);
                    //   Task.Run(() => { MessageBox.Show(String.Format($@"{bars.Name} - {bars.Volume[bars.Volume.Count - 2]} > {bars.AvgVolume} for bar {bars.Time[bars.Time.Count - 2]} ")); });
                    MainForm.grid.Invoke(new Action(() =>
                    {
                        MainForm.log.AppendText(String.Format($"{DateTime.Now.ToShortTimeString()} - {bars.Name} - {bars.Volume[bars.Volume.Count - 2]} > {bars.AvgVolume} for bar {bars.Time[bars.Time.Count - 2]} ") + Environment.NewLine);
                    }));
                    TelegramSender.SendToChannel(String.Format($@"{bars.Name} - {bars.Volume[bars.Volume.Count - 2]} > {bars.AvgVolume} for bar  {bars.Time[bars.Time.Count - 2]} "), 532280918);
                }
            }
        }
        
    }
}
