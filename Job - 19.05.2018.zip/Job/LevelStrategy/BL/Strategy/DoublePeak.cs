﻿using LevelStrategy.Model;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LevelStrategy.BL.Strategy
{
    public static class DoublePeak
    {
        public static void FindSignal(Bars bars, Mutex mtx, EventHandler<SignalData> eventHandler)
        {
            if(bars.Time.Last().TimeOfDay == new TimeSpan(14,15,0))
            {

            }
            if (bars.Time.Last().Hour > 10)
            {
                List<SignalData> headFrameSignal = DoubleLowHigh(bars.HeadBars, bars.HeadBars.StartIndex, 0.5, mtx);
                if (headFrameSignal.Count > 0)
                    headFrameSignal.ForEach(x => bars.HeadBars.listSignal.Add(x));
                headFrameSignal = HighLowFractals(bars.HeadBars, bars.HeadBars.StartIndex, 0.5, mtx);
                if (headFrameSignal.Count > 0)
                    headFrameSignal.ForEach(x => bars.HeadBars.listSignal.Add(x));
            }
            else
                return;
            if (bars.HeadBars.listSignal.Where(x => x.SignalType[0] == 'S').Count() > 0)
            {

            }

            if (bars.listSignal.Where(x => x.DateBpy2 > bars.Time.Last().AddMinutes(-17) && (x.SignalType.Contains("Двойное дно") || x.SignalType.Contains("Двойная вершина"))).Count() == 0)
            {
                List<SignalData> doubleFigureSignal = DoubleLowHigh(bars, bars.StartIndex, 0.25, mtx);
                #region проверка сигналов за весь день
                //if (bars.HeadBars.listSignal == null)
                //{
                //    bars.HeadBars.StartIndex = 0;
                //    List<SignalData> temp = new List<SignalData>();
                //    Bars tempBars = new Bars(bars.HeadBars);

                //    for (int i = tempBars.Count - 1; i >= bars.HeadBars.StartIndex; i--)
                //    {
                //        SignalData headFrameSignal = DoubleLowHigh(tempBars, bars.HeadBars.StartIndex, 0.6, mtx);
                //        if (headFrameSignal != null)
                //            temp.Add(headFrameSignal);
                //        tempBars.RemoveLastIndex(1);
                //    }
                //    bars.HeadBars.listSignal = temp;
                //}
                //else
                #endregion
                doubleFigureSignal.ForEach(x => CheckSignalFractals(x, bars, eventHandler));


            }
            if (bars.listSignal.Where(x => x.DateBpy2 > bars.Time.Last().AddMinutes(-17) && x.SignalType.Contains("относительно фракталов")).Count() == 0)
            {
                List<SignalData> temp = HighLowFractals(bars, bars.StartIndex, 0.25, mtx);

                temp.ForEach(x => CheckSignalFractals(x, bars, eventHandler));
                
            }
            bars.HeadBars.listSignal.Clear();
        }
        public static void CheckSignalDoubleLowHigh(SignalData doubleFigureSignal, Bars bars, EventHandler<SignalData> eventHandler)
        {
            if (doubleFigureSignal != null && bars.HeadBars.listSignal.Any(x => x.SignalType[0] == doubleFigureSignal.SignalType[0]))
            {
                bars.HeadBars.listSignal.Where(x => x.SignalType[0] == doubleFigureSignal.SignalType[0]).ToList().ForEach(e => bars.listSignal.Add(e));
                bars.listSignal.Last().color = Color.BlueViolet;
                bars.listSignal.Add(doubleFigureSignal);


                eventHandler(new object(), doubleFigureSignal);

                TelegramSender.SendToChannel(String.Format($@"{doubleFigureSignal.SignalType} - первое дно - {doubleFigureSignal.DateBsy} второе дно - {doubleFigureSignal.DateBpy2}"), 532280918);
            }
        }
        public static void CheckSignalFractals(SignalData farctalsFigureSiganl, Bars bars, EventHandler<SignalData> eventHandler)
        {
            if (farctalsFigureSiganl != null && bars.HeadBars.listSignal.Any(x => x.SignalType[0] == farctalsFigureSiganl.SignalType[0]))
            {
                bars.HeadBars.listSignal.Where(x => x.SignalType[0] == farctalsFigureSiganl.SignalType[0]).ToList().ForEach(e => bars.listSignal.Add(e));
                bars.listSignal.Last().color = Color.BlueViolet;
                bars.listSignal.Add(farctalsFigureSiganl);


                eventHandler(new object(), farctalsFigureSiganl);

                TelegramSender.SendToChannel(String.Format($@"{farctalsFigureSiganl.SignalType} - первое дно - {farctalsFigureSiganl.DateBsy} второе дно - {farctalsFigureSiganl.DateBpy2}"), 532280918);
            }
        }
        public static List<SignalData> DoubleLowHigh(Bars bars, int startIndex, double delta, Mutex mtx)
        {
            List<SignalData> temp = new List<SignalData>();
            MutexWorker.MutexOn(mtx, "Double Low/High");

            if (startIndex != 0)
            {
                double minToday = bars.Low[startIndex];
                int minIndex = startIndex;
                double maxToday = bars.High[startIndex];
                int maxIndex = startIndex;

                for (int i = startIndex; i < bars.Time.Count - 2; i++)
                {
                    if (/*bars.indexFractalsLow.Contains(i) &&*/ minToday > bars.Low[i])
                    {
                        minToday = bars.Low[i];
                        minIndex = i;
                    }

                    if (/*bars.indexFractalHigh.Contains(i) &&*/ maxToday < bars.High[i])
                    {
                        maxToday = bars.High[i];
                        maxIndex = i;
                    }
                }
                if (bars.Time.Last().Hour == 15)
                {

                }
                if (bars.indexFractalHigh.Any(x => x > minIndex) && (bars.Close.Last() > minToday) &&
                    (Common.PercentDiff(minToday, bars.Close.Last()) < delta || Common.PercentDiff(minToday, bars.Low[bars.Low.Count - 1]) < delta))
                {
                  //  MutexWorker.MutexOff(mtx, "Double Low/High");
                    temp.Add(new SignalData($"Long - Двойное дно - первое дно - {bars.Time[minIndex]} второе дно - {bars.Time.Last()}", new char[] { 'l', 'h', 'l' }, bars.Time[minIndex], bars.Time[bars.indexFractalHigh.First(x => x > minIndex)], bars.Time.Last(), minToday, Math.Round(minToday * 1.0004, bars.CountSigns), Math.Round(((minToday * 1.0004) * 1.004), bars.CountSigns), DateTime.Now, bars.Name + " " + bars.TimeFrame, Color.Lime));
                }
                if (bars.indexFractalsLow.Any(x => x > maxIndex) && (bars.Close.Last() < maxToday) &&
                    (Common.PercentDiff(maxToday, bars.Close.Last()) < delta || Common.PercentDiff(maxToday, bars.High[bars.High.Count - 1]) < delta))
                {
                  //  MutexWorker.MutexOff(mtx, "Double Low/High");
                    temp.Add(new SignalData($"Short - Двойная вершина - первая вершина - {bars.Time[maxIndex]} вторая вершина - {bars.Time.Last()}", new char[] { 'h', 'l', 'h' }, bars.Time[maxIndex], bars.Time[bars.indexFractalsLow.First(x => x > maxIndex)], bars.Time.Last(), maxToday, Math.Round(maxToday * 0.9996, bars.CountSigns), Math.Round(((maxToday * 0.9996) * 0.996), bars.CountSigns), DateTime.Now, bars.Name + " " + bars.TimeFrame, Color.Lime));

                }
            }
            else
            {
                MessageBox.Show($"На сегодняшний день - {DateTime.Now.Date} нет ни одной свечи!");
            }
            MutexWorker.MutexOff(mtx, "Double Low/High");
            return temp;
        }
        public static List<SignalData> HighLowFractals(Bars bars, int startIndex, double delta, Mutex mtx)
        {
            MutexWorker.MutexOn(mtx, "HighLowFractals");
            List<SignalData> temp = new List<SignalData>();
            if (bars.Time.Last().Hour == 14 && bars.Time.Last().Minute == 15)
            {

            }
            if (startIndex != 0)
            {
                double minTodayFract = 0;
                double maxTodayFract = 0;
                int minIndexFarct = 0;
                int maxIndexFract = 0;
                if (bars.indexFractalsLowSecond.Where(x => x > startIndex).Count() > 0)
                {
                    minTodayFract = bars.indexFractalsLowSecond.Where(x => x > startIndex).Min(y => bars.Low[y]);
                    minIndexFarct = bars.indexFractalsLowSecond.Where(x => x > startIndex && bars.Low[x] == minTodayFract).Last();
                }
                if (bars.indexFractalHighSecond.Where(x => x > startIndex).Count() > 0)
                {
                    maxTodayFract = bars.indexFractalHighSecond.Where(x => x > startIndex).Max(y => bars.High[y]);
                    maxIndexFract = bars.indexFractalHighSecond.Where(x => x > startIndex && bars.High[x] == maxTodayFract).Last();
                }


                if (minTodayFract != 0)
                {
                    double prevMinFract = 0;
                    if (bars.indexFractalsLowSecond.Where(x => x < minIndexFarct && x > startIndex).Count() > 0)
                        prevMinFract = bars.indexFractalsLowSecond.Where(x => x < minIndexFarct && x > startIndex).Min(y => bars.Low[y]);
                    else
                        prevMinFract = bars.Low[bars.indexFractalsLowSecond.Last(x => x < minIndexFarct)];
                    int indexPrevMinFract = bars.indexFractalsLowSecond.Last(x => x < minIndexFarct && prevMinFract == bars.Low[x]);

                    if (prevMinFract > minTodayFract && (Common.PercentDiffAbs(prevMinFract, bars.Close.Last()) < delta ||
                        Common.PercentDiffAbs(prevMinFract, bars.High[bars.High.Count - 1]) < delta) &&
                        MedianPriceForLevelForLowFract(bars, minIndexFarct, prevMinFract))
                    {
                      //  MutexWorker.MutexOff(mtx, "HighLowFractals");
                        temp.Add(new SignalData($"Short - Пробой вниз относительно фракталов - первый фрактал - {bars.Time[indexPrevMinFract]} второй фрактал - {bars.Time[minIndexFarct]}", new char[] { 'l', 'l', 'h' }, bars.Time[indexPrevMinFract], bars.Time[minIndexFarct], bars.Time.Last(), prevMinFract, Math.Round(prevMinFract * 0.9996, bars.CountSigns), Math.Round(((prevMinFract * 0.9996) * 0.9996), bars.CountSigns), DateTime.Now, bars.Name + " " + bars.TimeFrame, Color.Lime));
                    }
                }
                if (maxTodayFract != 0)
                {
                    double prevMaxFract = 0;
                    if (bars.indexFractalHighSecond.Where(x => x < maxIndexFract && x > startIndex).Count() > 0)
                        prevMaxFract = bars.indexFractalHighSecond.Where(x => x < maxIndexFract && x > startIndex).Max(y => bars.High[y]);
                    else
                        prevMaxFract = bars.High[bars.indexFractalHighSecond.Last(x => x < maxIndexFract)];
                    int indexPrevMaxFract = bars.indexFractalHighSecond.Last(x => x < maxIndexFract && prevMaxFract == bars.High[x]);

                    if (prevMaxFract < maxTodayFract && (Common.PercentDiffAbs(prevMaxFract, bars.Close.Last()) < delta ||
                        Common.PercentDiffAbs(prevMaxFract, bars.Low[bars.Low.Count - 1]) < delta) &&
                        MedianPriceForLevelForHighFract(bars, maxIndexFract, prevMaxFract))
                    {
                      //  MutexWorker.MutexOff(mtx, "HighLowFractals");
                        temp.Add(new SignalData($"Long - Пробой вверх относительно фракталов - первый фрактал - {bars.Time[indexPrevMaxFract]} вторая вершина - {bars.Time[maxIndexFract]}", new char[] { 'h', 'h', 'l' }, bars.Time[indexPrevMaxFract], bars.Time[maxIndexFract], bars.Time.Last(), prevMaxFract, Math.Round(prevMaxFract * 1.0004, bars.CountSigns), Math.Round(((prevMaxFract * 1.0004) * 1.0004), bars.CountSigns), DateTime.Now, bars.Name + " " + bars.TimeFrame, Color.Lime));
                    }
                }
            }
            else
            {
                MessageBox.Show($"На сегодняшний день - {DateTime.Now.Date} нет ни одной свечи!");
            }

            MutexWorker.MutexOff(mtx, "HighLowFractals");
            return temp;

        }

        public static bool MedianPriceForLevelForHighFract(Bars bars, int fine, double level)
        {
            for (int i = bars.Count - 1; i > fine; i--)
            {
                if ((Worker.GetBarsValue(bars, i, "Median") + Worker.GetBarsValue(bars, i - 1, "Median")) / 2 > level)
                    return true;
                else
                    return false;
            }
            return false;
        }
        public static bool MedianPriceForLevelForLowFract(Bars bars, int fine, double level)
        {
            for (int i = bars.Count - 1; i > fine; i--)
            {
                if ((Worker.GetBarsValue(bars, i, "Median") + Worker.GetBarsValue(bars, i - 1, "Median")) / 2 < level)
                    return true;
                else
                    return false;
            }
            return false;
        }
    }
}
