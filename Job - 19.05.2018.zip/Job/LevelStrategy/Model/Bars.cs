﻿using LevelStrategy.BL;
using System;
using System.Collections.Generic;
using System.Linq;

namespace LevelStrategy.Model
{
    public class Bars : Data
    {
        public Bars(Bars bars)
        {
            this.Close = new List<double>(bars.Close);
            this.Open = new List<double>(bars.Open);
            this.High = new List<double>(bars.High);
            this.Low = new List<double>(bars.Low);
            this.Volume = new List<double>(bars.Volume);
            this.Time = new List<DateTime>(bars.Time);
        }
        public Bars(string name, int timeFrame)
        {
            Name = name;
            TimeFrame = timeFrame;
            Time = new List<DateTime>();
            Open = new List<double>();
            High = new List<double>();
            Low = new List<double>();
            Close = new List<double>();
            Volume = new List<double>();
            listSignal = new List<SignalData>();//null;
        }
        public Bars(string classCode, string name, int timeFrame, int fractalPeriodParam = 0, 
            double[] level = null, bool longTrade = true, bool shortTrade= true)
        {
            ClassCod = classCode;
            Name = name;
            TimeFrame = timeFrame;
            Time = new List<DateTime>();
            Open = new List<double>();
            High = new List<double>();
            Low = new List<double>();
            Close = new List<double>();
            Volume = new List<double>();
            listSignal = new List<SignalData>();
            Orders = new List<Order>();
            timeToAction = new List<DateTime>();
            listLevelNew = new Dictionary<DateTime, double>();
            if (fractalPeriodParam != 0)
                fractalPeriod = fractalPeriodParam;

           // this.longTrade = longTrade;
          //  this.shortTrade = shortTrade;



            if (level != null)
                keyLevel = level;
            else
                keyLevel = new double[0];

            headLevel = new double[0];
            this.timeToAction = Common.CalculateListMinuts(TimeFrame, ClassCod, SecondsCycle);
            timeToFindFakeLevel = DateTime.Now.AddMinutes(-5);
            VolumeList = new List<DateTime>();
        }
        public override string Name { get; set; }

        public override string Alias { get; set; }

        public override int TimeFrame { get; set; }

        public override string ClassCod { get; set; }

        public List<double> Open { get; set; }

        public override List<double> Close { get; set; }

        public List<double> High { get; set; }

        public List<double> Low { get; set; }

        public override List<double> Volume { get; set; }

        public override List<DateTime> Time { get; set; }

        public override DateTime LastGet { get; set; }

        public override int Count { get { return Close.Count; } set { } }

        public List<double> MovingAverage { get; set; }

        public int periodMoving = 4;

        public string movingType = "Close";

        public string movingCalculateType = "EMA";

        public int periodStrategy = 200;

        public double fractalPeriod = 21;

        public int sdvig = 3;

        public double fractalPeriodSecond = 17;

        public int sdvigSecond = 0;

        public List<int> indexFractalHigh;

        public List<int> indexFractalsLow;

        public List<int> indexFractalHighSecond;

        public List<int> indexFractalsLowSecond;

        public int temp = 0;

        public DateTime LastTime => Time[Count - 1];

        
        public double StepPrice { get; set; }

        public int StepCount { get; set; } = 1;

        public int SecondsCycle { get; set; } = 120;

        public override string ProcessType { get; set; } = "Accept";
        
        public List<SignalData> listSignal { get; set; }

        public List<DateTime> timeToAction { get; set; }

        public int CountSigns { get; set; }

        public string Account => ClassCod == "SPBFUT" ? "41104ES" : "L01-00000F00";
           
        public override List<Order> Orders { get; set; }

        public override bool CheckOrder => Orders.Count > 0 && /*Orders.Any(x => x.transactionId > 0 && x.StopProfitId > 0) &&*/ DateTime.Now - LastGet > new TimeSpan(0, 1, 0);

        public DateTime LastCheckTable { get; set; }

        public bool CheckTableTime => DateTime.Now - LastCheckTable > new TimeSpan(0, 2, 0);

        public bool SendCheckTable = false;

        public  string first = "first";
        #region for history
        public  bool history = false;

        public DateTime From => new DateTime(2018, 05, 10, 10, 00, 00);

        public bool longTrade = false;

        public bool shortTrade = false;
        #endregion
        public double[] keyLevel;

        public double[] headLevel;

        public DateTime timeToFindFakeLevel;

        public override double AvgVolume { get; set; }

        public override List<DateTime> VolumeList { get; set; }

        public override Dictionary<DateTime, double> listLevelNew { get; set; }

        public Bars HeadBars { get; set; } = null;

        private int startIndex;
        public void RemoveLastIndex(int count)
        {
            Close.RemoveRange(Close.Count - count, count);
            Open.RemoveRange(Open.Count - count, count);
            High.RemoveRange(High.Count - count, count);
            Low.RemoveRange(Low.Count - count, count);
            Volume.RemoveRange(Volume.Count - count, count);
            Time.RemoveRange(Time.Count - count, count);
        }
        public int StartIndex
        {
            get { return startIndex; }

            set
            {
                DateTime from = Time.Last().Date;
                for (int i = Time.Count - 1; i >= 0; i--)
                {
                    if (Time[i] < from.AddDays(-value))
                    {
                        startIndex = i + 1;
                        break;
                    }
                }
            }
        }
    }
}
