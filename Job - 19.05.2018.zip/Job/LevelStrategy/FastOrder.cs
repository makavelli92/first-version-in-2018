﻿using LevelStrategy.DAL;
using LevelStrategy.Model;
using System;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LevelStrategy
{
    public partial class FastOrder : Form
    {
        private double lastPrice;

        private string name;

        private DataReception data;

        private Bars bars;

        private string type;
        
        public FastOrder(DataReception data, Bars bars, double price, string type)
        {
            InitializeComponent();
            
            this.name = bars.Name;
            this.data = data;
            this.bars = bars;
            this.type = type;
            lastPrice = price;
            textBox1.Text = "1";
            textBox2.Text = GetOneLotPrice(name).ToString();
        }

        private double GetOneLotPrice(string security)
        {
            int countLot = 0;
            if (textBox1.Text != String.Empty)
            {
                countLot = Int32.Parse(textBox1.Text);
            }
            if (security.Substring(0, 2) == "GZ" && security.Substring(0, 2) == "SR" && security.Substring(0, 2) == "Eu" && security.Substring(0, 2) == "GD" && security.Substring(0, 2) == "RI" && security.Substring(0, 2) == "Si" && security.Substring(0, 2) == "BR")
                security = security.Substring(0, 2);
            switch (security)
            {
                case "SBER":
                    return lastPrice * 10 * countLot;
                case "MOEX":
                    return lastPrice * 10 * countLot;
                case "ROSN":
                    return lastPrice * 10 * countLot;
                case "NLMK":
                    return lastPrice * 10 * countLot;
                case "LKOH":
                    return lastPrice * 1 * countLot;
                case "GAZP":
                    return lastPrice * 10 * countLot;
                case "URKA":
                    return lastPrice * 10 * countLot;
                case "CHMF":
                    return lastPrice * 10 * countLot;
                case "VTBR":
                    return lastPrice * 10000 * countLot;
                case "MAGN":
                    return lastPrice * 100 * countLot;
                case "MGNT":
                    return lastPrice * 1 * countLot;
                case "NVTK":
                    return lastPrice * 10 * countLot;
                case "SBERP":
                    return lastPrice * 100 * countLot;
                case "GMKN":
                    return lastPrice * 1 * countLot;
                case "ALRS":
                    return lastPrice * 100 * countLot;
                case "MTSS":
                    return lastPrice * 10 * countLot;
                case "PHOR":
                    return lastPrice * 1 * countLot;
                case "AFLT":
                    return lastPrice * 100 * countLot;
                case "YNDX":
                    return lastPrice * 1 * countLot;
                case "MTLRP":
                    return lastPrice * 10 * countLot;
                case "SNGS":
                    return lastPrice * 100 * countLot;
                case "FEES":
                    return lastPrice * 10000 * countLot;
                case "RTKM":
                    return lastPrice * 10 * countLot;
                case "RASP":
                    return lastPrice * 10 * countLot;
                case "GZ":
                    return lastPrice * 100 * countLot;
                case "SR":
                    return lastPrice * 100 * countLot;
                case "Eu":
                    return lastPrice * 1000 * countLot;
                case "GD":
                    return lastPrice * 1 * countLot;
                case "RI":
                    return lastPrice * 1 * countLot;
                case "Si":
                    return lastPrice * 1000 * countLot;
                case "BR":
                    return lastPrice * 10 * countLot;
                default:
                    return 0;
            }
        }

        private void textBox1_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!System.Text.RegularExpressions.Regex.IsMatch(e.KeyChar.ToString(), @"[0-9]") && e.KeyChar != 8)
                e.Handled = true;
        }

        private void textBox1_KeyUp(object sender, KeyEventArgs e)
        {
            textBox2.Text = GetOneLotPrice(name).ToString();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (!rbLong.Checked && !rbShort.Checked)
            {
                MessageBox.Show("Выбери Лонг/Шорт!");
                return;
            }
            // Task.Run(() =>
            //  {
            if (this.type == "WithOrder")
            {
                double priceOrder = rbLong.Checked ? lastPrice - lastPrice * 0.001 : lastPrice + lastPrice * 0.001;
                string type = rbLong.Checked ? "Long" : "Short";
                int countLots = Int32.Parse(textBox1.Text);
                double stop = rbLong.Checked ? lastPrice - lastPrice * 0.01 : lastPrice + lastPrice * 0.01;
                data.SetQUIKCommandDataObject(data.SW_Command, data.SR_FlagCommand, data.SW_FlagCommand, CreateOrderString(bars, priceOrder, countLots, type), "SetOrder");
                data.SetQUIKCommandDataObject(data.SW_Command, data.SR_FlagCommand, data.SW_FlagCommand, CreateTakeProfitStopLossString(bars, priceOrder, stop, countLots, type), "SetTP_SL");
            }
            else if(this.type == "WithoutOrder")
            {
                double priceOrder = !rbLong.Checked ? lastPrice - lastPrice * 0.001 : lastPrice + lastPrice * 0.001;
                string type = !rbLong.Checked ? "Long" : "Short";
                int countLots = Int32.Parse(textBox1.Text);
                double stop = !rbLong.Checked ? lastPrice - lastPrice * 0.01 : lastPrice + lastPrice * 0.01;
                data.SetQUIKCommandDataObject(data.SW_Command, data.SR_FlagCommand, data.SW_FlagCommand, CreateTakeProfitStopLossString(bars, priceOrder, stop, countLots, type), "SetTP_SL");
            }
            //});
            this.Close();
        }

        public static string CreateTakeProfitStopLossString(Bars bars, double level, double stopLevel, int count, string type)
        {
            int profit_size = (int)Math.Abs(((level - stopLevel) * 3) / bars.StepPrice);
            int stop_size = (int)(Math.Abs((level - stopLevel) / bars.StepPrice));
            StringBuilder builder = new StringBuilder();
            builder.Append(bars.Account).Append(';');
            builder.Append(bars.ClassCod).Append(';');
            builder.Append(bars.Name).Append(';');
            builder.Append(type[0] == 'S' ? "B" : "S").Append(';');
            builder.Append(level).Append(';');
            builder.Append(count).Append(';');
            builder.Append(profit_size).Append(';');
            builder.Append(stop_size);
            return builder.ToString();
        }

        private static string CreateOrderString(Bars bars, double level, int count, string type)
        {
            StringBuilder builder = new StringBuilder();
            builder.Append(bars.Account).Append(';');
            builder.Append(bars.ClassCod).Append(';');
            builder.Append(bars.Name).Append(';');
            builder.Append(level).Append(';');
            builder.Append(type[0] == 'S' ? "S" : "B").Append(';');
            builder.Append(count);
            return builder.ToString();
        }

        private void rbLong_CheckedChanged(object sender, EventArgs e)
        {
            rbShort.Checked = false;
        }

        private void rbShort_CheckedChanged(object sender, EventArgs e)
        {
            rbLong.Checked = false;
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            MessageBox.Show("Прошла минута, данные могли устареть!");
            this.Close();
        }

        private void timer2_Tick(object sender, EventArgs e)
        {
            label3.Text = (Int32.Parse(label3.Text) - 1).ToString();
        }
    }
}
