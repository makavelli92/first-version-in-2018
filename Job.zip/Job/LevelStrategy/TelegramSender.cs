﻿using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;

namespace LevelStrategy
{
    static class TelegramSender
    {
        static public void SendToChannel(string message, int chatId)
        {
            using (var webClient = new WebClient())
            {
                var pars = new NameValueCollection();

                pars.Add("text", message);
                pars.Add("chat_id", chatId.ToString());
                webClient.Proxy.Credentials = CredentialCache.DefaultCredentials;

                webClient.UploadValues("https://api.telegram.org/bot" + "535536044:AAFz7_nBGomxbzSL_hegGF7hkyvJFXa7hUc" + "/sendMessage", pars);
            }
        }
    }
}
