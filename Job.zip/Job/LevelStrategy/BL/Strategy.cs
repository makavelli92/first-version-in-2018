﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using LevelStrategy.Model;
using NLog;
using System.Drawing;
using System.Threading;
using System.Windows.Forms;

namespace LevelStrategy.BL
{
    public class Strategy
    {
        private static readonly ILogger Logger = LogManager.GetLogger("info");
        public static void FindSignal(Bars bars, EventHandler<SignalData> eventHandler, Mutex mtx)
        {
            List<SignalData> temp = new List<SignalData>();
            List<SignalData> signalToMainThread = new List<SignalData>();

            if (bars.LastTime == new DateTime(2017, 12, 25, 11, 20, 00))
            {
            }
            int bar = bars.Count - 1;
            int bsy;
            Logger.Warn($"{Thread.CurrentThread.ManagedThreadId} - Ищем сигнал...");
            if (bars.shortTrade)
            {
                Logger.Warn($"{Thread.CurrentThread.ManagedThreadId} - В лонге...");
                if (FindModelRepeatLevel(bar, bars.indexFractalHigh, bars.indexFractalsLow, bars, out bsy) == "Short")//&& DefenitionAreaNearLevel(bar) == "Short")
                {
                    bars.listSignal.Add(new SignalData("Short - Повторяющийся уровень", new char[] { 'h', 'h', 'h' }, bars.Time[bsy], bars.Time[(bar - 1)], bars.Time[bar], bars.High[bsy], Math.Round(bars.High[bsy] * 0.9996, bars.CountSigns), Math.Round(((bars.High[bsy] * 0.9996) * 0.996), bars.CountSigns), DateTime.Now, bars.Name + " " + bars.TimeFrame, DefenitionAreaNearLevel(bars, bar, bars.High[bsy])));
                    if (bars.listSignal.Last().color == Color.Brown || bars.listSignal.Last().Level < bars.keyLevel.Min())
                    {
                        if (bars.listSignal.Last().color != Color.Brown)
                            bars.listSignal.Last().SignalType = String.Format($"НИЖЕ МИН {bars.listSignal.Last().SignalType}");
                        bars.listSignal.Last().color = Color.Brown;
                        temp.Add(bars.listSignal.Last());
                    }
                    signalToMainThread.Add(bars.listSignal.Last());
                  //  eventHandler(new object(), bars.listSignal.Last());
                }
                if (FindModelMirrorLevel(bar, bars.indexFractalHigh, bars.indexFractalsLow, bars, out bsy) == "Short")// && DefenitionAreaNearLevel(bar) == "Short")
                {
                    bars.listSignal.Add(new SignalData("Short - Зеркальный уровень", new char[] { 'l', 'h', 'h' }, bars.Time[bsy], bars.Time[(bar - 1)], bars.Time[bar], bars.Low[bsy], Math.Round(bars.Low[bsy] * 0.9996, bars.CountSigns), Math.Round(((bars.Low[bsy] * 0.9996) * 0.996), bars.CountSigns), DateTime.Now, bars.Name + " " + bars.TimeFrame, DefenitionAreaNearLevel(bars, bar, bars.Low[bsy])));
                    if (bars.listSignal.Last().color == Color.Brown || bars.listSignal.Last().Level < bars.keyLevel.Min())
                    {
                        if (bars.listSignal.Last().color != Color.Brown)
                            bars.listSignal.Last().SignalType = String.Format($"НИЖЕ МИН {bars.listSignal.Last().SignalType}");
                        bars.listSignal.Last().color = Color.Brown;
                        temp.Add(bars.listSignal.Last());
                    }
                    signalToMainThread.Add(bars.listSignal.Last());
                    //eventHandler(new object(), bars.listSignal.Last());
                }
                if (AirLevel(bar, bars, out bsy) == "Short")//&& DefenitionAreaNearLevel(bar) == "Nothing")
                {
                    bars.listSignal.Add(new SignalData("Short - Воздушный уровень", new char[] { 'h', 'h', 'h' }, bars.Time[bsy], bars.Time[(bar - 1)], bars.Time[bar], bars.High[bsy], Math.Round(bars.High[bsy] * 0.9996, bars.CountSigns), Math.Round(((bars.High[bsy] * 0.9996) * 0.996), bars.CountSigns), DateTime.Now, bars.Name + " " + bars.TimeFrame, DefenitionAreaNearLevel(bars, bar, bars.High[bsy])));
                    if (bars.listSignal.Last().color == Color.Brown || bars.listSignal.Last().Level < bars.keyLevel.Min())
                    {
                        if (bars.listSignal.Last().color != Color.Brown)
                            bars.listSignal.Last().SignalType = String.Format($"НИЖЕ МИН {bars.listSignal.Last().SignalType}");
                        bars.listSignal.Last().color = Color.Brown;
                        temp.Add(bars.listSignal.Last());
                    }
                    signalToMainThread.Add(bars.listSignal.Last());
                    //eventHandler(new object(), bars.listSignal.Last());

                }
                Logger.Warn($"{Thread.CurrentThread.ManagedThreadId} - Лонг закончили");
            }
            if (bars.longTrade)
            {
                Logger.Warn($"{Thread.CurrentThread.ManagedThreadId} - В шорте...");
                if (FindModelRepeatLevel(bar, bars.indexFractalHigh, bars.indexFractalsLow, bars, out bsy) == "Long")   // && DefenitionAreaNearLevel(bar) == "Long")
                {
                    bars.listSignal.Add(new SignalData("Long - Повторяющийся уровень", new char[] { 'l', 'l', 'l' }, bars.Time[bsy], bars.Time[(bar - 1)], bars.Time[bar], bars.Low[bsy], Math.Round(bars.Low[bsy] * 1.0004, bars.CountSigns), Math.Round(((bars.Low[bsy] * 1.0004) * 1.004), bars.CountSigns), DateTime.Now, bars.Name + " " + bars.TimeFrame, DefenitionAreaNearLevel(bars, bar, bars.Low[bsy])));
                    if (bars.listSignal.Last().color == Color.Brown || bars.listSignal.Last().Level > bars.keyLevel.Max())
                    {
                        if (bars.listSignal.Last().color != Color.Brown)
                            bars.listSignal.Last().SignalType = String.Format($"ВЫШЕ МАКС {bars.listSignal.Last().SignalType}");
                        bars.listSignal.Last().color = Color.Brown;
                        temp.Add(bars.listSignal.Last());
                    }
                    signalToMainThread.Add(bars.listSignal.Last());
                    // eventHandler(new object(), bars.listSignal.Last());
                }
                if (FindModelMirrorLevel(bar, bars.indexFractalHigh, bars.indexFractalsLow, bars, out bsy) == "Long")// && DefenitionAreaNearLevel(bar) == "Long")
                {
                    bars.listSignal.Add(new SignalData("Long - Зеркальный уровень", new char[] { 'h', 'l', 'l' }, bars.Time[bsy], bars.Time[(bar - 1)], bars.Time[bar], bars.High[bsy], Math.Round(bars.High[bsy] * 1.0004, bars.CountSigns), Math.Round(((bars.High[bsy] * 1.0004) * 1.004), bars.CountSigns), DateTime.Now, bars.Name + " " + bars.TimeFrame, DefenitionAreaNearLevel(bars, bar, bars.High[bsy])));
                    if (bars.listSignal.Last().color == Color.Brown || bars.listSignal.Last().Level > bars.keyLevel.Max())
                    {
                        if (bars.listSignal.Last().color != Color.Brown)
                            bars.listSignal.Last().SignalType = String.Format($"ВЫШЕ МАКС {bars.listSignal.Last().SignalType}");
                        bars.listSignal.Last().color = Color.Brown;
                        temp.Add(bars.listSignal.Last());
                    }
                    signalToMainThread.Add(bars.listSignal.Last());
                    //eventHandler(new object(), bars.listSignal.Last());
                }
                if (AirLevel(bar, bars, out bsy) == "Long")// && DefenitionAreaNearLevel(bar) == "Nothing")
                {
                    bars.listSignal.Add(new SignalData("Long - Воздушный уровень", new char[] { 'l', 'l', 'l' }, bars.Time[bsy], bars.Time[(bar - 1)], bars.Time[bar], bars.Low[bsy], Math.Round(bars.Low[bsy] * 1.0004, bars.CountSigns), Math.Round(((bars.Low[bsy] * 1.0004) * 1.004), bars.CountSigns), DateTime.Now, bars.Name + " " + bars.TimeFrame, DefenitionAreaNearLevel(bars, bar, bars.Low[bsy])));
                    if (bars.listSignal.Last().color == Color.Brown || bars.listSignal.Last().Level > bars.keyLevel.Max())
                    {
                        if (bars.listSignal.Last().color != Color.Brown)
                            bars.listSignal.Last().SignalType = String.Format($"ВЫШЕ МАКС {bars.listSignal.Last().SignalType}");
                        bars.listSignal.Last().color = Color.Brown;
                        temp.Add(bars.listSignal.Last());
                    }
                    signalToMainThread.Add(bars.listSignal.Last());
                    // eventHandler(new object(), bars.listSignal.Last());
                }
            }

            Logger.Warn($"{Thread.CurrentThread.ManagedThreadId} {bars.Name} - Поиск сигнала окончен возвращаю объект");
            Logger.Warn($"{Thread.CurrentThread.ManagedThreadId} {bars.ProcessType} - ****************");
            bars.ProcessType = "SendCommand";
            Logger.Warn($"{Thread.CurrentThread.ManagedThreadId} {bars.ProcessType} - №№№№№№№№№№№№№№№№");

            SendSignal(temp.Where(x => NearMainLevel(bars, x.Level)).ToList());
            MutexWorker.MutexOff(mtx, "AddData");

            temp.Where(x => NearMainLevel(bars, x.Level)).ToList().ForEach(y => y.color = Color.Lime);
            //signalToMainThread.Where(t => t.color != Color.Lime).ToList().ForEach(x => eventHandler(new object(), x));
            //signalToMainThread.Where(t => t.color == Color.Lime).ToList().ForEach(x => eventHandler(new object(), x));
            signalToMainThread.Where(t => t.color == Color.Lime).ToList().ForEach(x => eventHandler(new object(), x));
            signalToMainThread.Where(t => t.color != Color.Lime).ToList().ForEach(x => eventHandler(new object(), x));

            if(bars.AvgVolume != -1 && ((bars.Volume.Last() > bars.AvgVolume && !bars.VolumeList.Contains(bars.Time.Last())) || 
                bars.Volume[bars.Volume.Count - 2] > bars.AvgVolume && !bars.VolumeList.Contains(bars.Time[bars.Time.Count - 2])))
            {
                if (bars.Volume.Last() > bars.AvgVolume)
                {
                    bars.VolumeList.Add(bars.Time.Last());
                  //  Task.Run(() => { MessageBox.Show(String.Format($@"{bars.Name} - {bars.Volume.Last()} > {bars.AvgVolume} for bar {bars.Time.Last()} ")); });
                    MainForm.grid.Invoke(new Action(() =>
                    {
                        MainForm.log.AppendText(String.Format($"{DateTime.Now.ToShortTimeString()} - {bars.Name} - {bars.Volume.Last()} > {bars.AvgVolume} for bar {bars.Time.Last()} ") + Environment.NewLine);
                    }));
                    TelegramSender.SendToChannel(String.Format($@"{bars.Name} - {bars.Volume.Last()} > {bars.AvgVolume} for bar {bars.Time.Last()}"), 532280918);
                }
                    
                else if (bars.Volume[bars.Volume.Count - 2] > bars.AvgVolume)
                {
                    bars.VolumeList.Add(bars.Time[bars.Time.Count - 2]);
                 //   Task.Run(() => { MessageBox.Show(String.Format($@"{bars.Name} - {bars.Volume[bars.Volume.Count - 2]} > {bars.AvgVolume} for bar {bars.Time[bars.Time.Count - 2]} ")); });
                    MainForm.grid.Invoke(new Action(() =>
                    {
                        MainForm.log.AppendText(String.Format($"{DateTime.Now.ToShortTimeString()} - {bars.Name} - {bars.Volume[bars.Volume.Count - 2]} > {bars.AvgVolume} for bar {bars.Time[bars.Time.Count - 2]} ") + Environment.NewLine);
                    }));
                    TelegramSender.SendToChannel(String.Format($@"{bars.Name} - {bars.Volume[bars.Volume.Count - 2]} > {bars.AvgVolume} for bar  {bars.Time[bars.Time.Count - 2]} "), 532280918);
                }
            }
        }
        private static void SendSignal(List<SignalData> temp)
        {
            if (temp.Count == 1)
            {
                SmtpClientHelper.SendEmail(String.Format($"{temp.Last().NameSecurity} - Получен сигнал"), $@"Сигнал получен для {temp.Last().NameSecurity}. Тип - {temp.Last().SignalType}. Уровень - {temp.Last().Level}. Bремя - {DateTime.Now}");
                TelegramSender.SendToChannel(String.Format($@"Сигнал получен для {temp.Last().NameSecurity}. Тип - {temp.Last().SignalType}. Уровень - {temp.Last().Level}. Bремя - {DateTime.Now}"), 532280918);
            }
            else if (temp.Count > 1)
            {
                StringBuilder builder = new StringBuilder();
                temp.ForEach(x => builder.AppendLine().AppendLine($@"{x.SignalType}. Уровень - {x.Level}."));
               // SmtpClientHelper.SendEmail(String.Format($"{temp.Last().NameSecurity} - Получено несколько сигналов"), builder.AppendLine().AppendLine($"Bремя - {DateTime.Now}").ToString());

                TelegramSender.SendToChannel(String.Format($"{temp.Last().NameSecurity} - Получено несколько сигналов") + builder.AppendLine().AppendLine($"Bремя - {DateTime.Now}").ToString(), 532280918);

            }
        }
        private static bool NearMainLevel(Bars bars, double levelSignal)
        {
            double level = levelSignal;
            //   double level = bars.Close[bar];
            string security = bars.Name.Substring(0, 2);
            double deviation = 0.004;
            if (security == "Eu" && security == "GD" && security == "RI" && security == "Si" && security == "BR")
                deviation = 0.0025;
            for (int i = 0; i < bars.headLevel.Length; i++)
            {
                if ((level < (bars.headLevel[i] + bars.headLevel[i] * deviation)) && level > (bars.headLevel[i] - bars.headLevel[i] * deviation))
                {
                    return true;
                }
            }
            return false;
        }

        public static Color DefenitionAreaNearLevel(Bars bars, int bar, double levelSignal) // Сигналы во все стороны (без разделения на/под уровнем)
        {
            double level = levelSignal;
         //   double level = bars.Close[bar];
            string security = bars.Name.Substring(0, 2);
            double deviation = 0.003;
            if (security == "Eu" && security == "GD" && security == "RI" && security == "Si" && security == "BR")
                deviation = 0.0015;
            for (int i = 0; i < bars.keyLevel.Length; i++)
            {
                if ((level < (bars.keyLevel[i] + bars.keyLevel[i] * deviation)) && level > (bars.keyLevel[i] - bars.keyLevel[i] * deviation))
                {
                    return Color.Brown;
                }
            }
            return Color.Cyan;
        }
        public static void ChangeColorConsole(bool change, ConsoleColor color = ConsoleColor.Red)
        {
            if (change)
                Console.ForegroundColor = ConsoleColor.Red;
            else
                Console.ResetColor();
        }

        /// <summary>
        /// Метод для определния с какого бара искать БСУ, если в графике меньше 540 баров, то с 0, если больше, то текущий бар - 540 баров назад
        /// </summary>
        /// <param name="bar"></param>
        /// <param name="periodStrategy"> Как глубоко будем искать БСУ</param>
        /// <returns></returns>
        public static int StartBarForFindBsy(int bar, int periodStrategy)             
        {
            if (bar - periodStrategy > 0)
                return bar - periodStrategy;
            return 0;
        }
        //(bar > 2 && Math.Abs(bars.High[bar - 2] - bars.High[bar - 3]) < TOLERANCE &&
        public static string AirLevel(int bar, Bars bars, out int bsy)
        {
            if (bar > 2 && bars.High[bar - 2] == bars.High[bar - 3] &&
                (bars.High[bar - 1] >= (bars.High[bar - 2] - (bars.High[bar - 2] / 2500)) && bars.High[bar - 1] <= bars.High[bar - 2]) &&
                (bars.High[bar] >= (bars.High[bar - 2] - (bars.High[bar - 2] / 2500)) && bars.High[bar] <= bars.High[bar - 2])
                )
            {
                bsy = bar - 2;
                return "Short";
            }
            else if (bar > 2 && bars.Low[bar - 2] == bars.Low[bar - 3] && 
                (bars.Low[bar - 1] <= (bars.Low[bar - 2] + (bars.Low[bar - 2] / 2500)) && bars.Low[bar - 1] >= bars.Low[bar - 2]) &&
                (bars.Low[bar] <= (bars.Low[bar - 2] + (bars.Low[bar - 2] / 2500)) && bars.Low[bar] >= bars.Low[bar - 2])
                )
            {
                bsy = bar - 2;
                return "Long";
            }
            bsy = 0;
            return "Nothing";
        }
        public static bool BsyAndPby1MirrorForLong(int bar, List<int> listHighFractal, Bars bars, out int bsy) // Для зеркального уровня, позиция в лонг
        {
            int fine = StartBarForFindBsy(bar, bars.periodStrategy);
            for (int temp = bar - 1; temp >= fine; temp--)
            {
                if (/*bars.High[temp] == bars.Low[bar]*/ (bars.High[temp] <= bars.Low[bar] && (bars.High[temp] + bars.StepPrice * bars.StepCount) >= bars.Low[bar]) && listHighFractal.Contains(temp))     // $$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$
                {
                    bsy = temp;
                    return true;
                }
            }
            bsy = 0;
            return false;
        }
        public static bool BsyAndPby1MirrorForShort(int bar, List<int> listLowFractal, Bars bars, out int bsy) // Для зеркального уровня, позиция в шорт
        {
            int fine = StartBarForFindBsy(bar, bars.periodStrategy);
            for (int temp = bar - 1; temp >= fine; temp--)
            {
                if (/*bars.Low[temp] == bars.High[bar]*/(bars.Low[temp] >= bars.High[bar] && (bars.Low[temp] - bars.StepPrice * bars.StepCount) <= bars.High[bar]) && listLowFractal.Contains(temp))     // $$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$
                {
                    bsy = temp;
                    return true;
                }
            }
            bsy = 0;
            return false;
        }
        public static bool BsyAndBpy1High(int bar, List<int> listHighFractal, Bars bars, out int bsy)               // Повторяющийся уровень для шорта
        {
            int fine = StartBarForFindBsy(bar, bars.periodStrategy);
            for (int temp = bar - 1; temp >= fine; temp--)
            {
                //if (bars.Time[temp] == new DateTime(2017, 12, 22, 12, 40, 00))
                //{

                //}
                if (/*bars.High[temp] == bars.High[bar]*/(bars.High[temp] >= bars.High[bar] && (bars.High[temp] - bars.StepPrice * bars.StepCount) <= bars.High[bar]) && listHighFractal.Contains(temp)) // $$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$
                {
                    bsy = temp;
                    return true;
                }
            }
            bsy = 0;
            return false;
        }
        public static bool BsyAndBpy1Low(int bar, List<int> listLowFractal, Bars bars, out int bsy)                // Повторяющийся уровень для лонга
        {
            int fine = StartBarForFindBsy(bar, bars.periodStrategy);
            for (int temp = bar - 1; temp >= fine; temp--)
            {
                if (/*bars.Low[temp] == bars.Low[bar]*/(bars.Low[temp] <= bars.Low[bar] && (bars.Low[temp] + bars.StepPrice * bars.StepCount) >= bars.Low[bar]) && listLowFractal.Contains(temp))      // $$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$
                {
                    bsy = temp;
                    return true;
                }
            }
            bsy = 0;
            return false;
        }
        public static bool Bpy1AndBpy2High(int bar, Bars bars)              // Подтверждение повторяющегося уровеня для шорта (БПУ2)
        {
            if (bars.High[bar] >= (bars.High[bar - 1] - (bars.High[bar - 1] / 2500)) && bars.High[bar] <= bars.High[bar - 1])
                return true;
            return false;
        }
        public static bool Bpy1AndBpy2Low(int bar, Bars bars)               // Подтверждение повторяющегося уровеня для лонга (БПУ2)   
        {
            if (bars.Low[bar] <= (bars.Low[bar - 1] + (bars.Low[bar - 1] / 2500)) && bars.Low[bar] >= bars.Low[bar - 1])
                return true;
            return false;
        }
        public static string FindModelRepeatLevel(int bar, List<int> listHighFractal, List<int> listLowFractal, Bars bars, out int bsy)                // Начало анализа баров для поиска повторяющегося уровня 
        {
            if (BsyAndBpy1High(bar - 1, listHighFractal, bars, out bsy) && Bpy1AndBpy2High(bar, bars))
            {
                return "Short";
            }
            if (BsyAndBpy1Low(bar - 1, listLowFractal, bars, out bsy) && Bpy1AndBpy2Low(bar, bars))
            {
                return "Long";
            }
            return "Nothing";
        }
        public static string FindModelMirrorLevel(int bar, List<int> listHighFractal, List<int> listLowFractal, Bars bars, out int bsy)                // Начало анализа баров для поиска зеркального уровня 
        {
            if (BsyAndPby1MirrorForShort(bar - 1, listLowFractal, bars, out bsy) && Bpy1AndBpy2High(bar, bars))
                return "Short";
            if (BsyAndPby1MirrorForLong(bar - 1, listHighFractal, bars, out bsy) && Bpy1AndBpy2Low(bar, bars))
                return "Long";
            return "Nothing";
        }
    }
}
