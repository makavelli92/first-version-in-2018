﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LevelStrategy.Model
{
    public class Position
    {
        public Position(string name, int curBal, double awgPrice, int stopCount, DateTime timeStopOn, double lastPrice, double posChange, int openBal, double stopPrice, int countLots)
        {
            Name = name;
            CurrnetBalance = curBal;
            AwgPositionPrice = awgPrice;
            StopCount = stopCount;
            TimeStop = timeStopOn;
            LastPrice = lastPrice;
            PosChange = posChange;
            OpenBalance = openBal;
            StopPrice = stopPrice;
            CountLotsStop = countLots;
        }
        public string Name { get; set; }

        public int CurrnetBalance { get; set; }

        public double AwgPositionPrice { get; set; }

        public int StopCount { get; set; }

        public DateTime TimeStop { get; set; }
        
        public double LastPrice { get; set; }

        public double PosChange { get; set; }

        public int OpenBalance { get; set; }

        public double StopPrice { get; set; }

        public int CountLotsStop { get; set; }
    }
}
